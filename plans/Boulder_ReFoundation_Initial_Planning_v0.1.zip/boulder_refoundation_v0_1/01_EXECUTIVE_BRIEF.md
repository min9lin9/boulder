# Boulder Re-foundation — Executive Brief

## 1. 지금 왜 멈추고 다시 기획하는가

현재 Boulder에는 이미 좋은 자산이 있다.

- workflow profile과 lane routing
- adapter 교체 가능성
- approval-gated handoff
- evidence와 readiness gate
- replay fixture
- routine → retro → reusable proposal의 학습 루프
- local-first, safe-write, explicit error의 구현 규율

하지만 현재 제품 정의와 코드 표면은 **OSS 저장소, Codex, release/maintainer workflow**에 강하게 결합돼 있다. 이 상태에서 Excel, 한글 문서, VC, 요식업 기능을 계속 직접 추가하면 Boulder는 플랫폼이 아니라 기능이 뒤섞인 거대한 vertical application이 된다.

문제는 기능 부족이 아니라 **확장 단위와 책임 경계의 부재**다.

## 2. 재정의할 제품

### 한 줄 정의

> **Boulder는 반복되는 디지털 업무를 Plan, Execute, Critique, Compound의 검토 가능한 lifecycle로 운영하고, 교체 가능한 Capability와 조합 가능한 Kit로 확장하는 오픈소스 업무 플랫폼이다.**

### 사용자에게 주는 약속

사용자는 다음을 할 수 있어야 한다.

1. 자연어 또는 구조화된 intent를 입력한다.
2. 실행 전에 무엇을, 왜, 어떤 도구로 할지 확인한다.
3. 필요한 부분만 인간이 승인한다.
4. 여러 adapter 중 환경에 맞는 실행자를 선택한다.
5. 결과와 근거, 실패, 변경 이력을 검토한다.
6. 반복된 성공 패턴을 workflow, template, capability 또는 kit으로 승격한다.
7. VC Kit를 제거하고 Restaurant Kit를 설치해도 Boulder core는 바뀌지 않는다.

## 3. 제품의 네 가지 핵심 객체

| 객체 | 정의 | 예시 |
|---|---|---|
| **Core** | lifecycle, contract, policy, evidence, authority를 제공하는 최소 runtime | plan orchestration, effect gate, event ledger |
| **Capability** | 하나의 재사용 가능한 행위와 그 계약 | workbook range 읽기, HWPX table 수정, 웹 검색 |
| **Capability Pack** | 같은 문제군의 Capability 묶음 | Spreadsheet Pack, Document Pack |
| **Kit** | 특정 산업·기능의 workflow, 정책, template, ontology 조합 | VC Kit, Restaurant Ops Kit, OSS Maintainer Kit |

## 4. 핵심 lifecycle

```mermaid
flowchart LR
    I[Human Intent] --> P[Plan]
    P --> E[Execute]
    E --> C[Critique]
    C -->|수정 필요| P
    C -->|통과| O[Compound]
    O --> R[Reusable Asset]
    R --> P
```

### Plan

목표, 범위, 입력, 사용 Capability, 예상 side effect, 승인 지점, 성공 기준을 명시한다.

### Execute

승인된 plan에 따라 Capability adapter를 호출하고 artifact와 telemetry를 생성한다.

### Critique

결과가 목표, 품질, 정책, 증거, 형식, 안전 기준을 충족하는지 독립적으로 검토한다.

### Compound

성공한 방식과 반복되는 패턴을 재사용 가능한 자산으로 승격한다. 단순 요약이 아니라 **조직 학습의 제품화**다.

## 5. 누구를 위한 플랫폼인가

### Operator

코드를 몰라도 Kit를 설치하고 반복 업무를 안정적으로 실행하려는 사람.

### Domain Expert / Kit Author

VC, 요식업, 회계 등 자기 업무 지식을 workflow와 policy로 구조화하려는 사람.

### Capability Developer

Excel, HWP, 데이터베이스, SaaS API 등 한 기능을 여러 Kit에서 재사용되게 만들려는 개발자.

### Administrator / Reviewer

권한, 데이터 경계, audit, 승인, 배포 신뢰도를 관리하려는 조직 관리자.

### Boulder Maintainer

Core를 작고 안정적으로 유지하면서 생태계가 외부에서 성장하게 만들려는 maintainer.

## 6. 제품 경계

### Boulder가 책임진다

- lifecycle와 state transition
- contract validation
- capability discovery·resolution
- side-effect declaration과 approval
- evidence·artifact·decision ledger
- critique routing
- compound candidate lifecycle
- versioning·compatibility
- sandbox와 trust policy의 기준

### Boulder가 책임지지 않는다

- 모든 산업의 업무 지식
- Excel이나 HWP 자체를 대체하는 office suite
- 특정 model/provider의 성능
- 모든 작업을 자동 승인하는 자율 swarm
- Kit 내부의 투자·세무·법률 판단
- 외부 시스템의 credential과 business policy 소유권

## 7. 첫 번째 검증 전략

VC 하나만 만들면 vertical-specific 구조를 플랫폼으로 오인할 위험이 있다. 따라서 성격이 크게 다른 두 Kit를 동시에 prototype한다.

| Reference Kit | 대표 workflow | 검증하는 것 |
|---|---|---|
| **VC Screening Kit** | 자료 접수 → 분석 → challenge → screening decision | 복잡한 증거, 판단, human authority |
| **Restaurant Ops Kit** | 재고 → 발주 → 스케줄 → 마감 보고 | 반복 운영, spreadsheet, 실시간 예외, 비개발자 경험 |

두 Kit가 같은 Core·Spreadsheet Pack·Document Pack을 재사용하면 플랫폼 가설이 강화된다. Core 수정이 반복되면 abstraction이 잘못된 것이다.

## 8. 성공의 정의

초기 성공은 기능 수가 아니라 다음으로 측정한다.

- 사용자가 15분 안에 첫 safe preview를 얻는가
- side effect가 100% 선언되고 승인 흐름을 우회할 수 없는가
- 서로 다른 두 Kit가 Core 변경 없이 동일 Capability를 재사용하는가
- 실행 결과가 evidence와 연결되는가
- 반복 작업이 검토 가능한 compound candidate로 승격되는가
- Capability 개발자가 문서만으로 adapter를 구현할 수 있는가
- 실패 시 무엇이 실패했고 어떻게 복구할지 설명 가능한가

## 9. 제안하는 결정

기존 개발을 무기한 중단하는 것이 아니라, 기능 추가를 잠시 멈추고 다음을 먼저 확정한다.

1. Boulder Constitution
2. Core/Capability/Kit 경계
3. Capability SDK v1 contract
4. effect·permission·evidence model
5. 두-domain no-build prototype
6. 0.1.x → v2 strangler migration plan

이 순서가 확정되기 전에는 Excel, HWP, VC 기능을 core에 직접 추가하지 않는다.
