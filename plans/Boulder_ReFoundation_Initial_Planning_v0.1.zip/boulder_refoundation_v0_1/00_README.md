# Boulder Re-foundation 초기 기획 문서 패키지 v0.1

- **상태:** 초기 방향 정렬용 초안
- **작성 기준일:** 2026-07-20
- **현재 코드 기준:** `min9lin9/boulder@10732cb0f3c1b5032ce4b2a542f8c514b658bd12`
- **대상:** Boulder maintainer, core contributor, capability developer, kit author
- **문서 성격:** 제품 재정의 + 디자인 씽킹 기반 탐색 계획 + 플랫폼 구조 초안

## 핵심 결론

Boulder는 특정 코딩 에이전트나 특정 산업 애플리케이션이 아니다.

> **Boulder는 사람의 의도를 검토 가능한 계획으로 바꾸고, 교체 가능한 Capability를 통해 실행하며, 결과를 독립적으로 Critique하고, 검증된 반복 패턴을 재사용 가능한 자산으로 Compound하는 오픈소스 업무 플랫폼이다.**

Boulder의 안정적인 중심은 다음 네 단계다.

```text
Plan → Execute → Critique → Compound
```

이 네 단계는 단일 고정 workflow가 아니라 **모든 workflow가 따르는 lifecycle contract**다. 각 단계에는 복수의 planner, executor, reviewer, learning adapter를 연결할 수 있어야 한다.

플랫폼 위에는 두 종류의 확장 자산이 올라간다.

1. **Capability / Capability Pack**  
   Excel·문서·HWP/HWPX·PDF·웹·데이터베이스·이메일처럼 여러 산업에서 반복 사용되는 기능.
2. **Industry / Function Kit**  
   VC, 요식업, 회계, 법률, 리서치, OSS 유지보수처럼 특정 업무의 객체·정책·template·workflow를 조합한 설치 단위.

현재 Boulder의 OSS maintainer 기능은 폐기 대상이 아니라 향후 `oss-maintainer-kit`으로 분리할 첫 reference kit다.

## 문서 읽는 순서

| 순서 | 문서 | 질문 |
|---:|---|---|
| 1 | `01_EXECUTIVE_BRIEF.md` | 무엇을, 왜 다시 만드는가? |
| 2 | `02_DESIGN_THINKING_FOUNDATION.md` | 어떤 사람의 어떤 문제를 어떻게 발견·검증할 것인가? |
| 3 | `03_DESIGN_INTENT_AND_PRINCIPLES.md` | Boulder의 존재 이유와 정신 모델은 무엇인가? |
| 4 | `04_AS_IS_REVERSE_ENGINEERING_AND_GAP.md` | 현재 코드에서 무엇을 유지·일반화·분리해야 하는가? |
| 5 | `05_PLATFORM_BLUEPRINT.md` | 목표 플랫폼은 어떤 층과 계약으로 구성되는가? |
| 6 | `06_CAPABILITY_SDK_AND_REGISTRY.md` | Capability를 어떻게 만들고 신뢰하고 배포하는가? |
| 7 | `07_KIT_MODEL_AND_REFERENCE_PACKS.md` | 산업별 Kit와 Excel/HWP Pack은 어떻게 조합되는가? |
| 8 | `08_VALIDATION_AND_MVP_ROADMAP.md` | 무엇부터 검증하고 어떤 조건에서 다음 단계로 가는가? |
| 9 | `09_BOULDER_CONSTITUTION_DRAFT.md` | 구현이 바뀌어도 지켜야 할 헌법은 무엇인가? |
| 10 | `10_DECISION_LOG_AND_OPEN_QUESTIONS.md` | 합의된 것과 아직 결정하지 않은 것은 무엇인가? |
| - | `SOURCES.md` | 공식 근거는 무엇인가? |

## 포함된 계약 예시

- `schemas/capability-manifest.example.yaml`
- `schemas/kit-manifest.example.yaml`
- `schemas/workflow-profile.example.yaml`
- `schemas/compound-candidate.example.yaml`

이 예시는 구현 확정본이 아니라 **토론 가능한 prototype**이다. 디자인 씽킹 관점에서 문서 자체를 첫 번째 저비용 prototype으로 취급한다.

## 이번 초안에서 의도적으로 하지 않은 것

- 특정 언어·package manager·marketplace를 최종 확정하지 않음
- Excel/HWP 구현 library를 확정하지 않음
- VC를 Boulder core에 포함하지 않음
- 현재 저장소의 모든 source file을 line-by-line 감사했다고 주장하지 않음
- 기존 0.1.x 사용자 migration을 자동화했다고 가정하지 않음
- hosted service 또는 완전 자율 실행을 전제하지 않음

## 다음 리뷰에서 받아야 할 결정

1. 이 한 줄 정의가 Boulder의 장기 정체성으로 충분히 넓고 명확한가?
2. `Plan → Execute → Critique → Compound`를 public lifecycle로 확정할 것인가?
3. Capability와 Kit를 별도 배포 단위로 확정할 것인가?
4. 두 개의 상이한 reference kit—`VC`와 `Restaurant Ops`—로 범용성을 검증할 것인가?
5. 현재 OSS maintainer 기능을 core에서 `oss-maintainer-kit`으로 단계적으로 추출할 것인가?
