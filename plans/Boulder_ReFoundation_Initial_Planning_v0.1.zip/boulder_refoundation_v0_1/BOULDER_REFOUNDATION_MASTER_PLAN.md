# Boulder Re-foundation Master Initial Plan v0.1

- 작성 기준일: 2026-07-20
- 코드 snapshot: `min9lin9/boulder@10732cb0f3c1b5032ce4b2a542f8c514b658bd12`
- 상태: 초기 방향 정렬·사용자 연구·architecture prototype용

> 이 문서는 각 개별 기획 문서를 한 파일로 합친 검토본이다. 세부 수정과 ADR 관리는 개별 문서를 기준으로 한다.


---

# Boulder Re-foundation — Executive Brief

## 1. 지금 왜 멈추고 다시 기획하는가

현재 Boulder에는 이미 좋은 자산이 있다.

- workflow profile과 lane routing
- adapter 교체 가능성
- approval-gated handoff
- evidence와 readiness gate
- replay fixture
- routine → retro → reusable proposal의 학습 루프
- local-first, safe-write, explicit error의 구현 규율

하지만 현재 제품 정의와 코드 표면은 **OSS 저장소, Codex, release/maintainer workflow**에 강하게 결합돼 있다. 이 상태에서 Excel, 한글 문서, VC, 요식업 기능을 계속 직접 추가하면 Boulder는 플랫폼이 아니라 기능이 뒤섞인 거대한 vertical application이 된다.

문제는 기능 부족이 아니라 **확장 단위와 책임 경계의 부재**다.

## 2. 재정의할 제품

### 한 줄 정의

> **Boulder는 반복되는 디지털 업무를 Plan, Execute, Critique, Compound의 검토 가능한 lifecycle로 운영하고, 교체 가능한 Capability와 조합 가능한 Kit로 확장하는 오픈소스 업무 플랫폼이다.**

### 사용자에게 주는 약속

사용자는 다음을 할 수 있어야 한다.

1. 자연어 또는 구조화된 intent를 입력한다.
2. 실행 전에 무엇을, 왜, 어떤 도구로 할지 확인한다.
3. 필요한 부분만 인간이 승인한다.
4. 여러 adapter 중 환경에 맞는 실행자를 선택한다.
5. 결과와 근거, 실패, 변경 이력을 검토한다.
6. 반복된 성공 패턴을 workflow, template, capability 또는 kit으로 승격한다.
7. VC Kit를 제거하고 Restaurant Kit를 설치해도 Boulder core는 바뀌지 않는다.

## 3. 제품의 네 가지 핵심 객체

| 객체 | 정의 | 예시 |
|---|---|---|
| **Core** | lifecycle, contract, policy, evidence, authority를 제공하는 최소 runtime | plan orchestration, effect gate, event ledger |
| **Capability** | 하나의 재사용 가능한 행위와 그 계약 | workbook range 읽기, HWPX table 수정, 웹 검색 |
| **Capability Pack** | 같은 문제군의 Capability 묶음 | Spreadsheet Pack, Document Pack |
| **Kit** | 특정 산업·기능의 workflow, 정책, template, ontology 조합 | VC Kit, Restaurant Ops Kit, OSS Maintainer Kit |

## 4. 핵심 lifecycle

```mermaid
flowchart LR
    I[Human Intent] --> P[Plan]
    P --> E[Execute]
    E --> C[Critique]
    C -->|수정 필요| P
    C -->|통과| O[Compound]
    O --> R[Reusable Asset]
    R --> P
```

### Plan

목표, 범위, 입력, 사용 Capability, 예상 side effect, 승인 지점, 성공 기준을 명시한다.

### Execute

승인된 plan에 따라 Capability adapter를 호출하고 artifact와 telemetry를 생성한다.

### Critique

결과가 목표, 품질, 정책, 증거, 형식, 안전 기준을 충족하는지 독립적으로 검토한다.

### Compound

성공한 방식과 반복되는 패턴을 재사용 가능한 자산으로 승격한다. 단순 요약이 아니라 **조직 학습의 제품화**다.

## 5. 누구를 위한 플랫폼인가

### Operator

코드를 몰라도 Kit를 설치하고 반복 업무를 안정적으로 실행하려는 사람.

### Domain Expert / Kit Author

VC, 요식업, 회계 등 자기 업무 지식을 workflow와 policy로 구조화하려는 사람.

### Capability Developer

Excel, HWP, 데이터베이스, SaaS API 등 한 기능을 여러 Kit에서 재사용되게 만들려는 개발자.

### Administrator / Reviewer

권한, 데이터 경계, audit, 승인, 배포 신뢰도를 관리하려는 조직 관리자.

### Boulder Maintainer

Core를 작고 안정적으로 유지하면서 생태계가 외부에서 성장하게 만들려는 maintainer.

## 6. 제품 경계

### Boulder가 책임진다

- lifecycle와 state transition
- contract validation
- capability discovery·resolution
- side-effect declaration과 approval
- evidence·artifact·decision ledger
- critique routing
- compound candidate lifecycle
- versioning·compatibility
- sandbox와 trust policy의 기준

### Boulder가 책임지지 않는다

- 모든 산업의 업무 지식
- Excel이나 HWP 자체를 대체하는 office suite
- 특정 model/provider의 성능
- 모든 작업을 자동 승인하는 자율 swarm
- Kit 내부의 투자·세무·법률 판단
- 외부 시스템의 credential과 business policy 소유권

## 7. 첫 번째 검증 전략

VC 하나만 만들면 vertical-specific 구조를 플랫폼으로 오인할 위험이 있다. 따라서 성격이 크게 다른 두 Kit를 동시에 prototype한다.

| Reference Kit | 대표 workflow | 검증하는 것 |
|---|---|---|
| **VC Screening Kit** | 자료 접수 → 분석 → challenge → screening decision | 복잡한 증거, 판단, human authority |
| **Restaurant Ops Kit** | 재고 → 발주 → 스케줄 → 마감 보고 | 반복 운영, spreadsheet, 실시간 예외, 비개발자 경험 |

두 Kit가 같은 Core·Spreadsheet Pack·Document Pack을 재사용하면 플랫폼 가설이 강화된다. Core 수정이 반복되면 abstraction이 잘못된 것이다.

## 8. 성공의 정의

초기 성공은 기능 수가 아니라 다음으로 측정한다.

- 사용자가 15분 안에 첫 safe preview를 얻는가
- side effect가 100% 선언되고 승인 흐름을 우회할 수 없는가
- 서로 다른 두 Kit가 Core 변경 없이 동일 Capability를 재사용하는가
- 실행 결과가 evidence와 연결되는가
- 반복 작업이 검토 가능한 compound candidate로 승격되는가
- Capability 개발자가 문서만으로 adapter를 구현할 수 있는가
- 실패 시 무엇이 실패했고 어떻게 복구할지 설명 가능한가

## 9. 제안하는 결정

기존 개발을 무기한 중단하는 것이 아니라, 기능 추가를 잠시 멈추고 다음을 먼저 확정한다.

1. Boulder Constitution
2. Core/Capability/Kit 경계
3. Capability SDK v1 contract
4. effect·permission·evidence model
5. 두-domain no-build prototype
6. 0.1.x → v2 strangler migration plan

이 순서가 확정되기 전에는 Excel, HWP, VC 기능을 core에 직접 추가하지 않는다.


---

# Boulder Design Thinking Foundation

## 1. 디자인 씽킹은 무엇에 적용되는가

`Plan → Execute → Critique → Compound`는 Boulder가 **업무를 운영하는 lifecycle**이다.

디자인 씽킹은 Boulder 자체를 **어떻게 발견하고 설계하고 검증할지**에 적용하는 제품 개발 방식이다. 둘을 혼동하지 않는다.

```text
Boulder를 설계하는 과정
Empathize → Define → Ideate → Prototype → Test

Boulder가 사용자의 업무를 운영하는 과정
Plan → Execute → Critique → Compound
```

Stanford d.school은 디자인 씽킹을 Empathize, Define, Ideate, Prototype, Test의 다섯 mode로 소개하며, 이를 선형 단계가 아니라 필요에 따라 오가는 도구 모음으로 설명한다. IDEO는 사람의 desirability, 기술적 feasibility, 조직·사업의 viability를 함께 보라고 강조한다. 이 기획은 두 관점을 결합한다.

## 2. Design Challenge

### 초기 문제문

> 다양한 산업의 사용자는 반복 업무를 자동화하고 싶지만, 현재 도구는 너무 범용적이어서 업무 맥락을 모르거나 너무 vertical해서 재사용이 어렵다. 실행 과정과 근거가 불투명하고, 외부 도구를 안전하게 연결하기 어렵고, 반복 작업에서 학습한 내용을 다음 작업에 구조적으로 재사용하기도 어렵다.

### How Might We

1. 어떻게 비개발자가 Kit를 설치한 뒤 15분 안에 안전한 첫 결과를 얻도록 할까?
2. 어떻게 Core를 바꾸지 않고 Excel, HWP, 웹, 데이터베이스 Capability를 추가하도록 할까?
3. 어떻게 VC와 요식업처럼 다른 산업을 하나의 lifecycle로 표현하되 도메인 의미를 잃지 않을까?
4. 어떻게 모든 side effect를 실행 전에 이해하고 승인할 수 있게 할까?
5. 어떻게 Critique가 Execute의 자기합리화가 되지 않도록 독립성을 유지할까?
6. 어떻게 Compound가 쓰레기 같은 자동 생성물의 축적이 아니라 검증된 조직 학습이 되게 할까?
7. 어떻게 Capability와 Kit의 신뢰도, 출처, license, 권한 요구를 설치 전에 알게 할까?
8. 어떻게 현재 Boulder 사용자의 자산을 버리지 않고 새 플랫폼으로 이동시킬까?

## 3. 핵심 가설

| ID | 가설 | 틀렸다는 신호 |
|---|---|---|
| H1 | 대부분의 디지털 업무는 Plan–Execute–Critique–Compound로 설명 가능하다 | 특정 업무가 lifecycle을 우회해야만 자연스럽다 |
| H2 | Capability와 Kit를 분리하면 산업 간 재사용성이 높아진다 | Kit마다 Capability를 fork한다 |
| H3 | 사용자는 완전 자율성보다 preview와 설명 가능한 통제를 선호한다 | approval이 반복 사용을 심각하게 방해한다 |
| H4 | Spreadsheet·Document 계열이 가장 높은 공통 재사용 가치를 가진다 | reference Kit가 office capability를 거의 공유하지 않는다 |
| H5 | 반복 작업의 evidence를 모으면 compound candidate를 안정적으로 발견할 수 있다 | candidate가 과도하게 많거나 품질이 낮다 |
| H6 | 현재 Boulder의 profile·handoff·gate·routine 구조는 재사용 가능하다 | 일반화 비용이 새로 만드는 비용보다 크다 |
| H7 | 두 개의 극단적으로 다른 reference Kit가 abstraction 품질을 빠르게 드러낸다 | 비교가 오히려 범위를 과도하게 넓힌다 |
| H8 | Local-first는 초기 신뢰와 도입 장벽을 낮춘다 | 필요한 collaboration·central control이 막힌다 |

## 4. Empathize — 누구에게 무엇을 배울 것인가

### 연구 대상

| 사용자군 | 최소 인터뷰 | 관찰할 업무 |
|---|---:|---|
| 비개발자 Operator | 5 | 반복 보고, 문서·spreadsheet 편집, 승인 |
| Domain Expert / Kit Author | 5 | 업무 규칙 설명, 예외 처리, 책임 경계 |
| Capability Developer | 5 | API 연결, schema, test, 배포·호환성 |
| Reviewer / Administrator | 4 | 권한, audit, compliance, rollback |
| 기존 Boulder 사용자·maintainer | 4 | 현재 가치, 병목, migration 위험 |

### 인터뷰 질문

#### Operator

- 최근 일주일에 세 번 이상 반복한 업무는 무엇인가?
- 그 업무를 시작할 때 가장 먼저 찾는 정보는 무엇인가?
- 자동화 결과를 믿지 못하게 만드는 순간은 언제인가?
- 실행 전에 반드시 확인해야 하는 것은 무엇인가?
- 실패했을 때 어떤 상태로 되돌아가야 안심되는가?
- “이 업무는 다음부터 자동으로 해도 된다”고 판단하는 조건은 무엇인가?

#### Domain Expert

- 업무 결과보다 더 중요한 판단 과정은 무엇인가?
- 절대 자동화하면 안 되는 결정은 무엇인가?
- 신입에게 업무를 넘길 때 어떤 checklist와 example을 주는가?
- 예외는 어디에서 가장 자주 발생하는가?
- 좋은 결과와 나쁜 결과를 가르는 숨은 기준은 무엇인가?

#### Capability Developer

- 새로운 integration을 만들 때 반복되는 boilerplate는 무엇인가?
- input/output, permission, side effect, rollback을 어떻게 표현하고 싶은가?
- local library와 remote API를 같은 contract로 다룰 수 있는가?
- compatibility break를 어떻게 감지하고 싶은가?
- 설치 전에 사용자에게 어떤 trust 정보를 보여줘야 하는가?

## 5. Define — 사용자 Job과 문제 프레임

### 핵심 Jobs-to-be-Done

#### Operator JTBD

> 반복 업무가 생겼을 때, 내가 사용하는 도구와 조직 규칙을 유지하면서도 실행 전에 내용을 검토하고, 결과와 근거를 남기며, 다음번에는 더 적은 노력으로 수행하고 싶다.

#### Kit Author JTBD

> 도메인 지식을 코드 전체에 박아 넣지 않고 workflow, policy, template, ontology로 포장해 다른 조직이 설치하고 수정하게 하고 싶다.

#### Capability Developer JTBD

> 하나의 기능을 여러 산업 Kit가 사용할 수 있도록 안정적인 contract, test harness, versioning, permission model과 함께 배포하고 싶다.

#### Administrator JTBD

> 어떤 Capability가 어떤 데이터와 시스템에 접근하며 어떤 side effect를 만들 수 있는지 파악하고, 필요한 human gate와 audit를 강제하고 싶다.

## 6. Ideate — 탐색할 구조 대안

### 대안 A: Mega Core

모든 office·web·industry 기능을 Boulder core에 포함.

- 장점: 초기 설치가 단순함
- 단점: core가 빠르게 비대해지고 domain coupling이 증가
- 판단: 기각 후보

### 대안 B: Thin Core + Capability + Kit

Core는 lifecycle·contract·policy만 제공하고 기능과 도메인을 외부 package로 분리.

- 장점: 확장성과 독립 배포
- 단점: SDK와 versioning 설계 비용
- 판단: 현재 우선안

### 대안 C: Kit가 자체 runtime 보유

각 Kit가 독립적으로 workflow engine을 포함하고 Boulder는 launcher만 담당.

- 장점: domain 자유도
- 단점: lifecycle, safety, audit가 파편화
- 판단: 제한적으로만 허용

### 대안 D: Hosted Marketplace 중심

Cloud registry와 hosted execution을 먼저 구축.

- 장점: 배포와 사용성이 좋을 수 있음
- 단점: 신뢰, 비용, 보안, scope가 초기 학습을 압도
- 판단: 초기 non-goal

## 7. Prototype — 학습 순서

### Prototype 0: 문서 prototype

현재 패키지의 Constitution, architecture, manifest example로 이해도를 검증한다.

### Prototype 1: No-build workflow storyboard

실제 code 없이 VC와 Restaurant workflow를 카드로 연결한다.

```text
Intent card
→ Plan card
→ Capability card
→ Effect/Approval card
→ Artifact card
→ Critique card
→ Compound candidate card
```

관찰 포인트:

- 사용자가 lifecycle을 이해하는가
- Capability와 Kit 차이를 설명할 수 있는가
- 승인 지점이 과도하거나 부족한가
- artifact와 evidence의 차이가 이해되는가

### Prototype 2: Wizard-of-Oz

백엔드는 사람이 운영하되 CLI/UI가 plan preview, approval, result, critique, learning을 보여준다. 실제 자동화보다 interaction과 trust를 먼저 검증한다.

### Prototype 3: Local vertical slice

Spreadsheet Pack의 `read → analyze → write → diff → verify`와 두 Kit의 한 workflow를 실제 실행한다.

### Prototype 4: External Capability

제3자가 문서만 보고 Capability 하나를 구현하도록 한다. 내부 팀의 설명이 필요하면 SDK가 충분히 명확하지 않은 것이다.

## 8. Test — 무엇을 측정하는가

### Desirability

- 사용자가 기존 방식 대신 Boulder를 다시 선택하는가
- Plan preview가 신뢰를 높이는가
- Kit 설치 개념이 이해되는가
- Compound candidate가 실제 재사용 욕구와 맞는가

### Feasibility

- 동일 Core에서 두 Kit를 실행할 수 있는가
- Capability contract가 local/remote adapter를 모두 표현하는가
- side-effect와 rollback을 기계적으로 검사할 수 있는가
- version mismatch가 실행 전에 감지되는가

### Viability / Sustainability

- Maintainer가 Core를 작게 유지할 수 있는가
- Kit와 Capability가 독립적으로 release 가능한가
- license와 trust review가 운영 가능한가
- community contribution이 review burden보다 큰 가치를 만드는가

## 9. 학습 기록 형식

모든 design experiment는 다음 형식으로 기록한다.

```yaml
experiment:
  id:
  hypothesis:
  participant_segment:
  prototype:
  task:
  observed_behavior:
  evidence:
  surprise:
  decision:
  next_experiment:
```

“좋아 보였다”는 결론으로 인정하지 않는다. 실제 행동, artifact, 완료 시간, 오류, 질문, 재사용 의사를 evidence로 남긴다.

## 10. 디자인 씽킹 적용의 종료 조건

디자인 씽킹은 끝없는 workshop이 아니다. 다음이 확보되면 implementation specification으로 넘어간다.

- 네 사용자군의 반복되는 핵심 Job이 확인됨
- 두-domain prototype에서 공통 Core 경계가 유지됨
- Capability manifest를 외부 개발자가 이해함
- preview/approval model이 사용성과 안전의 균형을 이룸
- 주요 risk와 non-goal이 합의됨
- v2 migration의 최소 호환 경로가 정의됨


---

# Boulder Design Intent & Product Principles

## 1. Design Intent

Boulder가 해결하려는 본질적인 문제는 “AI가 일을 못한다”가 아니다.

사람과 조직의 업무는 다음 이유로 반복 가능하게 만들기 어렵다.

- 의도와 성공 기준이 암묵적이다.
- 업무가 여러 tool과 사람 사이에서 끊긴다.
- 실행 권한과 책임이 불명확하다.
- 결과는 남지만 판단 근거와 실패 과정은 사라진다.
- 반복되는 작업을 발견해도 재사용 가능한 형태로 승격되지 않는다.
- 산업별 software는 깊지만 폐쇄적이고, 범용 agent는 넓지만 맥락이 얕다.

Boulder의 Design Intent는 이 간극을 메우는 것이다.

> **사람의 암묵적 업무를 설명 가능하고 조합 가능하며 검증 가능하고 학습 가능한 운영 자산으로 바꾼다.**

## 2. Product Mental Model

```mermaid
flowchart LR
    U[Intent] --> P[Plan]
    P --> X[Execute]
    X --> C[Critique]
    C -->|Revise| P
    C -->|Accept| M[Compound]
    M --> A[Reusable Asset]
    A --> P

    E[Evidence] -.-> P
    E -.-> C
    H[Human Authority] -.-> P
    H -.-> X
    H -.-> C
    Y[Policy] -.-> P
    Y -.-> X
    Y -.-> C
```

### Plan

“무엇을 할까?”가 아니라 다음을 구조화한다.

- 목표
- scope와 non-goal
- context와 evidence
- task graph
- 사용할 Capability와 version
- 예상 side effect
- approval point
- acceptance criteria
- fallback과 recovery

### Execute

Plan을 자의적으로 재해석하지 않고 contract에 따라 행위를 수행한다.

- deterministic step과 agentic step을 구분
- 실행 전 preview 제공
- effect scope 제한
- artifact·telemetry·error 기록
- partial failure와 retry를 명시
- 승인되지 않은 외부 effect 차단

### Critique

Execute의 부속 검사가 아니라 독립적인 판단 단계다.

- 결과 정확성
- 근거 충실성
- 정책 준수
- 사용자 의도 적합성
- 형식·품질
- side-effect 검증
- 반대 관점 또는 red-team
- 재실행·수정·승인·거절 결정

### Compound

과거를 저장하는 것이 아니라 미래의 비용을 줄이는 학습 단계다.

- 반복 task 발견
- 안정적인 plan pattern 발견
- 재사용 가능한 prompt/template/schema 추출
- failure mode와 recovery rule 축적
- Capability 또는 Kit 후보 생성
- 인간 검토 후 승격
- 효과가 없는 asset은 폐기 또는 archive

## 3. 제품 층

| 층 | 책임 |
|---|---|
| **Boulder Core** | lifecycle, contracts, policy, evidence, authority, event state |
| **Capability SDK** | 재사용 행위의 표준 interface |
| **Capability Pack** | 관련 Capability 묶음 |
| **Kit SDK** | domain workflow·policy·template·ontology 조합 |
| **Experience Layer** | CLI, desktop, API, MCP, web UI |
| **Registry / Trust Layer** | discovery, version, provenance, license, review status |

## 4. Design Principles

### 1. Human Intent Before Automation

자동화 수준보다 의도와 책임의 명확성을 우선한다.

### 2. Small Core, Rich Edges

산업 지식과 tool-specific logic은 Capability와 Kit에 둔다. Core는 lifecycle contract만 소유한다.

### 3. Everything Important Is a Contract

input, output, effect, permission, evidence, failure, version을 구조화한다. 중요한 행동을 prompt 관습에 의존하지 않는다.

### 4. Preview Before Mutation

write, send, publish, pay, delete, sign 같은 행위는 preview와 policy evaluation을 거친다.

### 5. Evidence Is a First-Class Object

결과뿐 아니라 어떤 evidence와 version으로 판단했는지 연결한다.

### 6. Critique Must Be Independently Routable

같은 adapter가 실행과 검토를 모두 할 수는 있지만, 사용자가 별도 reviewer를 연결하고 독립 context를 강제할 수 있어야 한다.

### 7. Compound Is Earned, Not Automatic

반복됐다는 이유만으로 asset을 만들지 않는다. 안정성, 재사용성, evidence, 인간 검토를 통과해야 한다.

### 8. Capabilities Compose; Kits Orchestrate

Capability는 작은 재사용 행위이고, Kit는 domain 의미를 가진 조합이다. Kit가 저수준 integration을 복제하지 않는다.

### 9. Domain Knowledge Never Leaks Into Core

VC의 Deal, Restaurant의 Menu, OSS의 Pull Request는 Core type이 아니다. Kit schema로 정의한다.

### 10. Provider-Neutral, Environment-Aware

특정 model, agent, office suite, SaaS는 adapter 기본값일 수 있지만 Core dependency가 아니다.

### 11. Local-First, Network-Explicit

로컬 실행과 데이터 경계를 기본값으로 삼고 외부 전송은 명시적으로 선언·승인한다.

### 12. Safe Failure Is a Product Feature

부분 실패, retry, rollback, manual handoff를 정상적인 workflow 상태로 다룬다.

### 13. Progressive Disclosure

비개발자는 Kit 설치와 preview만 보아도 되고, 전문가만 lane·policy·schema를 내려다본다.

### 14. Versioned and Inspectable

모든 public contract는 version을 갖고 diff와 compatibility를 설명한다.

### 15. Open Source Means Extensible Governance

코드 공개만으로 충분하지 않다. contribution, trust, license, deprecation, security review 절차도 공개한다.

## 5. Non-goals

Boulder는 다음이 아니다.

- 범용 office suite
- 모든 산업을 내장한 monolith
- 완전 자율 swarm runtime
- 특정 LLM의 wrapper
- 단순 prompt library
- scheduler만 제공하는 automation tool
- benchmark leaderboard
- credential vault
- 규제 산업의 최종 책임자
- domain Kit의 business logic을 대신 소유하는 플랫폼

## 6. 용어

| 용어 | 의미 |
|---|---|
| Intent | 사용자의 목표와 맥락 |
| Workflow | lifecycle 안에서 수행되는 task graph |
| Stage | Plan, Execute, Critique, Compound |
| Lane | stage 내부의 세부 routing boundary |
| Capability | 계약을 가진 최소 재사용 행위 |
| Adapter | Capability를 특정 library/API/runtime으로 구현한 것 |
| Pack | 관련 Capability의 배포 묶음 |
| Kit | 특정 domain의 workflow·policy·template·ontology 묶음 |
| Artifact | 실행이 만든 결과물 |
| Evidence | 주장이나 평가를 뒷받침하는 근거 |
| Effect | 외부 세계나 상태에 미치는 영향 |
| Gate | transition을 허용·차단하는 조건 |
| Compound Candidate | 재사용 자산으로 승격을 검토 중인 패턴 |

## 7. 정체성 검증 질문

새 기능을 Core에 넣기 전에 묻는다.

1. 두 개 이상의 서로 다른 Kit에서 필요한가?
2. 독립 input/output과 failure semantics가 있는가?
3. Capability로 외부 배포할 수 없는 이유가 있는가?
4. domain object를 Core에 새로 추가하지 않고 표현할 수 있는가?
5. 이 기능이 Plan, Execute, Critique, Compound 중 어디에 속하는가?
6. side effect와 evidence를 명확히 선언할 수 있는가?
7. 제거해도 기존 public contract가 유지되는가?

답이 불명확하면 Core에 넣지 않는다.


---

# Boulder AS-IS Reverse Engineering & Platform Gap Review

## 1. 검토 범위와 한계

- 기준 저장소: `min9lin9/boulder@10732cb0f3c1b5032ce4b2a542f8c514b658bd12`
- 공개 package: `boulder-oss-cli@0.1.16`
- 검토한 공식 자료:
  - `README.md`
  - `package.json`
  - `boulder.yaml`
  - `docs/WORKFLOW_ARCHITECTURE.md`
  - `docs/BOULDER_FINAL_PRODUCT_PLAN.md`
  - `docs/OPERATOR_WORKFLOW_STACK.md`
  - `src/AGENTS.md`
  - `src/types.ts`
  - `src/workflow-profile-builtins.ts`
  - `src/capability-source-schema.ts`

이 문서는 초기 플랫폼 재기획을 위한 architecture review다. 전체 source를 line-by-line audit한 최종 reverse engineering report는 아니다.

## 2. 현재 제품 정의

현재 README와 package metadata는 Boulder를 **OSS repository를 evidence-backed Codex workflow로 만드는 operator kit**으로 정의한다. 사용자 표면은 `intake → plan → execute → verify → record`이며, 내부에는 `intake, plan, critic, handoff, execute, verify, compound, record` lane이 있다.

현재 구조의 핵심 의도는 이미 다음을 포함한다.

- planner와 executor를 replaceable adapter로 취급
- Boulder가 packet, handoff, verification, evidence, compound를 소유
- 외부 실행을 approval-gated로 제한
- local verification을 최종 기준으로 유지
- repeated routine을 학습 자산 후보로 축적

즉, **플랫폼의 씨앗은 존재한다.** 병목은 lifecycle 부재가 아니라 현재 contract와 product narrative가 OSS/Codex domain에 고정된 것이다.

## 3. 현재 코드 구조의 개념 지도

```text
CLI Surface
├─ init / inspect / quickstart
├─ profile
├─ capability import / doctor
├─ handoff
├─ verify / readiness / replay
├─ routine / retro / skill propose
└─ export

Core-ish Contracts
├─ BoulderManifest
├─ ResolvedWorkflowProfile
├─ LaneRoute
├─ ExternalPolicy
├─ Handoff Packet
├─ Run Event
└─ Readiness Check

Vertical Logic
├─ repository inspection
├─ PR / issue / release workflow assumptions
├─ GJC planning preference
├─ LazyCodex execution preference
├─ Codex capability inventory
└─ product/service/release readiness evidence
```

## 4. 유지할 강점

### Typed Record 중심

`src/AGENTS.md`는 class보다 plain function과 typed record를 선호하고, JSON contract의 additive evolution을 요구한다. Plugin SDK와 manifest 중심 플랫폼에 잘 맞는 규율이다.

### Side-effect-light command router

`cli.ts`가 domain logic을 직접 소유하지 않고 command module로 routing하도록 하는 원칙은 package 분리에 유리하다.

### Safe path/write posture

workspace containment, traversal·symlink·hardlink 방어, protected path, explicit error code는 향후 Capability sandbox의 좋은 토대다.

### Workflow Profile

현재 `ResolvedWorkflowProfile`은 stage별 owner, adapter, mode, evidence requirement, fallback을 표현한다. 범용 profile contract로 확장할 가치가 높다.

### External Policy

외부 실행은 기본 blocked, raw workspace content 금지, sanitized packet만 approval 이후 허용한다. 이 정책은 업종 일반의 effect model로 일반화 가능하다.

### Handoff Independence

planner와 executor를 packet으로 분리하고 review receipt를 요구하는 구조는 adapter 독립성과 human-in-the-loop에 유용하다.

### Readiness / Replay / Evidence

fixture와 evidence를 통해 “문서상 준비”와 “실행으로 증명된 준비”를 분리한 점은 Critique와 Compound에 중요한 기반이다.

### Routine / Retro

반복 task를 capture하고 review-first로 skill proposal 후보를 만드는 현재 loop는 Compound의 초기 구현으로 볼 수 있다.

## 5. 플랫폼화를 막는 결합

### 5.1 Product Definition Coupling

현재 정의는 `OSS repository`, `Codex`, `maintainer`, `release`를 제품 본체로 취급한다. 향후에는 이것들을 `oss-maintainer-kit`의 domain language로 내려야 한다.

### 5.2 Workflow Purpose가 닫혀 있음

현재 `WorkflowPurpose`는 다음 union이다.

```text
programming | research | ops | review | release
```

VC, restaurant, finance, document operations를 추가할 때 Core type을 수정해야 한다. 목적은 namespaced extension 또는 Kit-owned taxonomy가 돼야 한다.

### 5.3 Built-in Adapter와 Model Preference

`programming-default` profile은 GJC, LazyCodex, 특정 model preference를 직접 포함한다. 이는 좋은 default였지만 Core built-in이 아니라 Kit 또는 distribution preset으로 이동해야 한다.

### 5.4 Capability는 “후보 source”이지 Runtime Plugin이 아님

현재 capability manifest는 다음 정도를 표현한다.

- source
- kind: skill / adapter / agent-catalog
- trust status
- candidate command

하지만 실제 Capability SDK에 필요한 다음이 없다.

- input/output schema
- stage support
- effect·permission
- preview / execute / verify / rollback hook
- health check
- determinism
- evidence contract
- dependency와 compatibility
- artifact type
- data classification

### 5.5 Execute Contract가 Tool-neutral하지 않음

현재 execute는 주로 external executor candidate와 local Codex fallback을 routing한다. Excel range edit, HWP document transform, database query 같은 작은 typed action을 직접 표현하는 표준 interface가 필요하다.

### 5.6 Verification이 Repo Command 중심

현재 verification은 manifest의 shell command와 repo readiness에 최적화돼 있다. 범용 Critique는 schema validation, artifact diff, business rule, human review, adversarial check 등 다양한 evaluator를 지원해야 한다.

### 5.7 Compound가 Promotion System으로 완결되지 않음

현재 routine/retro/skill proposal은 좋은 시작이지만 다음이 없다.

- pattern similarity
- recurrence threshold와 confidence
- performance evidence
- candidate type 선택: template / workflow / capability / kit
- reviewer와 approval
- versioning·deprecation
- effectiveness monitoring

### 5.8 Kit라는 독립 배포 단위가 없음

현재 profile과 fixture가 domain package 역할을 일부 하지만, ontology, policy, template, workflow, recommended capabilities, dashboard, sample data, test를 하나의 Kit로 묶는 contract가 없다.

### 5.9 Human Authority가 External Send Approval로 축소됨

조직 업무에서는 approve, reject, veto, override, delegate, sign, dual control, conflict check가 필요하다. Core에 domain-specific committee를 넣지 않되 일반 Authority Event contract는 제공해야 한다.

## 6. Keep / Generalize / Extract / Retire

| 현재 자산 | 결정 | 목표 위치 |
|---|---|---|
| Workflow profile | **Generalize** | `packages/core-profile` |
| Lane routing | **Keep + Generalize** | lifecycle runtime |
| Handoff packet | **Generalize** | plan/execution artifact contract |
| Review receipt | **Generalize** | authority/effect gate |
| Protected paths / safe writes | **Keep** | capability sandbox |
| Run event / evidence | **Generalize** | event & evidence core |
| Readiness registry | **Generalize** | evaluator/gate registry |
| Replay fixture | **Generalize** | workflow test harness |
| Routine / retro | **Generalize** | compound engine |
| Capability source import | **Replace gradually** | capability registry client |
| GJC/LazyCodex defaults | **Extract** | `oss-maintainer-kit` preset |
| Repo inspection | **Extract** | OSS repository capability |
| Release/product/service readiness | **Extract** | `oss-maintainer-kit` policy |
| Codex-specific inventory | **Extract** | Codex environment pack |
| `boulder.yaml` legacy manifest | **Migrate** | compatibility loader |
| current CLI commands | **Wrap / Preserve** | v1 compatibility layer |

## 7. 권장 migration posture

### Rewrite가 아니라 Strangler

새 v2 core를 기존 코드 옆에 만들고 command별로 새 contract에 연결한다.

```text
Current CLI
   ├─ legacy command path
   └─ v2 compatibility adapter
           ↓
       Boulder Core v2
           ↓
   OSS Maintainer Kit
```

### 제안 package layout

```text
packages/
  core/
  contracts/
  runtime/
  policy/
  evidence/
  authority/
  capability-sdk/
  kit-sdk/
  registry/
  cli/

capabilities/
  repo/
  spreadsheet/
  document/
  hwp/
  web/

kits/
  oss-maintainer/
  vc-screening/
  restaurant-ops/
```

### 첫 추출 순서

1. Public type과 schema를 `contracts`로 이동
2. current profile loader를 v2 profile adapter로 감쌈
3. GJC/LazyCodex preference를 OSS Kit로 이동
4. readiness gate를 generic evaluator contract로 감쌈
5. repo-specific command를 capability로 이동
6. routine/retro를 compound candidate service로 일반화
7. v1 CLI의 output contract를 compatibility test로 고정

## 8. 기술적 위험

| 위험 | 영향 | 완화 |
|---|---|---|
| 지나친 추상화 | 사용자가 실제 가치를 못 느낌 | 두 reference Kit vertical slice |
| 기존 사용자 break | 신뢰 하락 | v1 compatibility layer와 fixture |
| Capability SDK 과대설계 | 개발 속도 저하 | 최소 hook부터 시작 |
| HWP format 난이도 | Office Pack 지연 | HWPX/convert/inspect 단계 분리 |
| Marketplace를 너무 일찍 구축 | 운영 부담 | local registry manifest부터 |
| Critique 비용·지연 | UX 저하 | risk-based reviewer routing |
| Compound 자산 쓰레기화 | 검색·신뢰 악화 | promotion gate와 usage telemetry |
| Domain leakage | Core 재비대화 | Constitution과 architecture test |

## 9. 초기 판단

현재 Boulder는 버릴 prototype이 아니다. 다음으로 재해석해야 한다.

> 현재 Boulder 0.1.x는 범용 플랫폼의 실패작이 아니라, **미래 Boulder Core가 지원해야 할 첫 번째 vertical Kit를 Core와 함께 구현한 상태**다.

따라서 재기획의 핵심은 기존 기능을 삭제하는 것이 아니라 **무엇이 Core이고 무엇이 OSS Maintainer Kit인지 분리하는 것**이다.


---

# Boulder Platform Blueprint v0.1

## 1. 목표 구조

```mermaid
flowchart TB
    subgraph Experience["Experience Layer"]
      CLI[CLI]
      UI[Desktop / Web UI]
      API[API / MCP]
    end

    subgraph Kits["Kit Layer"]
      OSS[OSS Maintainer Kit]
      VC[VC Kit]
      REST[Restaurant Ops Kit]
      OTHER[Other Kits]
    end

    subgraph Packs["Capability Packs"]
      SHEET[Spreadsheet Pack]
      DOC[Document Pack]
      HWP[HWP/HWPX Pack]
      WEB[Web & Research Pack]
      DATA[Data / DB Pack]
      COMM[Communication Pack]
    end

    subgraph Platform["Boulder Platform"]
      KITSDK[Kit SDK]
      CAPSDK[Capability SDK]
      REG[Registry & Resolver]
      CORE[Plan–Execute–Critique–Compound Runtime]
      POLICY[Policy & Authority]
      EVID[Evidence / Artifact / Event Ledger]
      SANDBOX[Effect Gate & Sandbox]
    end

    Experience --> Kits
    Kits --> Packs
    Kits --> KITSDK
    Packs --> CAPSDK
    KITSDK --> CORE
    CAPSDK --> CORE
    CORE --> POLICY
    CORE --> EVID
    CORE --> SANDBOX
    REG --> KITSDK
    REG --> CAPSDK
```

## 2. Core가 소유하는 최소 객체

### Intent

사용자가 원하는 outcome과 context. 원문 입력을 보존하되 normalized objective를 별도로 생성한다.

### Work Context

참고 data, environment, actor, policy scope, installed capability snapshot.

### Plan

task graph, capability binding, effect, gate, acceptance, fallback을 포함한 실행 계약.

### Step

Plan 안의 최소 실행 노드. 하나 이상의 Capability invocation을 포함할 수 있다.

### Artifact

실행 결과물. file, record, message draft, report, decision package 등.

### Evidence

Artifact나 평가를 뒷받침하는 source와 provenance.

### Critique

criterion별 평가, issue, severity, confidence, recommended transition.

### Decision / Authority Event

사람 또는 승인된 시스템이 transition을 허용·차단·override한 기록.

### Compound Candidate

반복 pattern을 재사용 자산으로 승격하기 위한 후보.

## 3. Public lifecycle contract

### Plan Contract

#### 입력

- intent
- actor와 authority scope
- context references
- Kit workflow/profile
- installed Capability inventory
- policy snapshot

#### 출력

- objective와 scope
- task graph
- capability requirements
- selected adapters
- expected artifact
- effect summary
- approval gates
- acceptance criteria
- critique strategy
- fallback/recovery
- evidence requirements

#### 불변조건

- 모든 step은 입력과 출력 schema를 가진다.
- 모든 side effect는 선언된다.
- 승인 전 mutation step은 실행 가능 상태가 아니다.
- binding되지 않은 Capability가 있으면 plan은 `unresolved`다.

### Execute Contract

#### 입력

- sealed 또는 approved plan
- step
- capability binding
- scoped credentials/reference
- effect permit

#### 출력

- result artifact
- execution status
- telemetry
- effect receipt
- evidence references
- errors / warnings
- rollback token 또는 recovery instruction

#### 불변조건

- plan 범위를 넘어서는 action을 수행하지 않는다.
- tool output을 artifact와 evidence로 구분한다.
- partial execution을 숨기지 않는다.
- retry는 idempotency와 effect semantics를 따른다.

### Critique Contract

#### 입력

- intent
- plan
- artifacts
- evidence
- execution telemetry
- policy
- evaluator profile

#### 출력

- criterion result
- detected issue
- severity
- confidence
- independent challenge
- pass / revise / human-review / reject
- remediation suggestion

#### 불변조건

- evaluator provenance를 기록한다.
- 실행자와 독립 reviewer를 연결할 수 있다.
- missing evidence는 pass로 처리하지 않는다.
- hard gate는 aggregate score로 상쇄되지 않는다.

### Compound Contract

#### 입력

- 완료 workflow history
- task recurrence
- critique outcome
- human override
- usage/effectiveness telemetry
- existing asset registry

#### 출력

- candidate type
- extracted pattern
- generalized input/output
- required Capability
- evidence
- risk
- proposed owner/reviewer
- suggested asset location
- promotion status

#### candidate type

```text
template
checklist
prompt
policy
workflow profile
capability
capability pack
kit update
failure rule
replay fixture
```

## 4. Lifecycle state machine

```mermaid
stateDiagram-v2
    [*] --> Draft
    Draft --> Planned
    Planned --> Unresolved
    Unresolved --> Planned
    Planned --> AwaitingApproval
    AwaitingApproval --> Approved
    AwaitingApproval --> Rejected
    Approved --> Running
    Running --> Waiting
    Waiting --> Running
    Running --> Failed
    Failed --> Planned
    Running --> Executed
    Executed --> Critiquing
    Critiquing --> Planned: revise
    Critiquing --> HumanReview
    HumanReview --> Planned: override/revise
    HumanReview --> Accepted
    Critiquing --> Accepted
    Accepted --> Compounding
    Compounding --> Completed
    Completed --> [*]
```

모든 workflow가 모든 상태를 거칠 필요는 없다. 그러나 mutation, 외부 communication, financial action, signing 등은 policy에 의해 mandatory approval state를 요구할 수 있다.

## 5. Effect Model

### Effect class

| Level | 예시 | 기본 정책 |
|---|---|---|
| `none` | 계산, 분류 | 자동 허용 가능 |
| `read-local` | local file 읽기 | scope 확인 |
| `read-external` | API 조회, web fetch | data policy 확인 |
| `write-local` | file 생성·수정 | preview/diff |
| `write-external` | SaaS record 변경 | explicit approval |
| `communicate` | 이메일·메시지 전송 | recipient/content approval |
| `financial` | 주문·결제·송금 | dual control |
| `legal-sign` | 계약 서명 | human-only |
| `destructive` | 삭제·취소 | explicit approval + rollback |
| `identity/admin` | 권한·계정 변경 | privileged gate |

Capability는 자신의 최대 effect를 manifest에 선언하고 각 invocation은 실제 effect를 더 좁게 선언한다.

## 6. Resolution Model

```text
Task Requirement
→ Capability ID / Interface
→ Compatible Capability Version
→ Available Adapter
→ Environment & Policy Check
→ Binding
```

예:

```text
Requirement: spreadsheet.range.write@^1
Candidates:
  - local-ooxml adapter
  - libreoffice adapter
  - remote-sheet adapter
Resolution inputs:
  file type, local availability, data policy, effect policy, fidelity need
```

특정 구현 이름은 초기 예시일 뿐이며 Core는 알지 않는다.

## 7. Kit Runtime

Kit는 다음을 제공한다.

- domain object schema
- workflow profile
- task templates
- policy bundle
- critique rubric
- human role/authority suggestions
- artifact templates
- recommended Capability
- sample fixture
- onboarding interview
- dashboard definition
- migration/version hooks

Kit가 직접 adapter를 구현할 수는 있지만, 재사용 가능성이 있으면 Capability Pack으로 분리해야 한다.

## 8. Event & Evidence Ledger

모든 중요한 transition은 append-only event로 기록한다.

```yaml
event:
  id:
  workflow_id:
  stage:
  actor:
  action:
  contract_version:
  input_hashes:
  output_hashes:
  effect:
  approval_ref:
  evidence_refs:
  status:
  timestamp:
  parent_event_hash:
```

### 핵심 원칙

- raw sensitive data를 event에 복제하지 않는다.
- artifact와 evidence는 content-addressed reference를 사용할 수 있다.
- plan, policy, capability version을 함께 기록한다.
- 사후 수정은 새 event와 새 revision으로 표현한다.
- export 가능한 human-readable decision narrative를 제공한다.

## 9. Experience Layer

### CLI

개발자와 자동화에 최적화. JSON output을 first-class로 유지한다.

### Desktop / Local UI

비개발자에게 plan preview, approval, artifact diff, critique, history를 시각화한다.

### API / MCP

외부 agent와 tool이 lifecycle contract를 사용하도록 한다.

### Progressive Disclosure

기본 사용자 경험:

```text
Install Kit
→ Describe Work
→ Review Plan
→ Approve Effects
→ Review Result
→ Save Improvement
```

전문가 경험:

```text
Inspect Contracts
→ Override Binding
→ Edit Policy
→ Add Capability
→ Review Compound Candidate
```

## 10. 제안 repository layout

```text
packages/
  contracts/
  core-runtime/
  planner/
  executor/
  critique/
  compound/
  policy/
  authority/
  evidence/
  capability-sdk/
  kit-sdk/
  registry/
  cli/
  desktop/

capabilities/
  spreadsheet/
  document/
  hwp/
  pdf/
  web/
  repository/
  database/
  communication/

kits/
  oss-maintainer/
  vc-screening/
  restaurant-ops/

examples/
fixtures/
docs/
```

## 11. Architecture fitness rules

CI에서 다음을 검사한다.

- Core package가 Kit package를 import하지 않는다.
- Core enum에 domain noun을 추가하지 않는다.
- Capability는 effect와 schema 없이 publish할 수 없다.
- Kit는 unavailable Capability에 대한 fallback 또는 requirement를 선언한다.
- side-effecting step은 policy gate를 우회할 수 없다.
- Critique 결과 없이 workflow를 Compound로 보내지 않는다.
- Compound candidate는 source run과 evidence를 참조한다.


---

# Boulder Capability SDK & Registry Initial Specification

## 1. Capability 정의

> **Capability는 명확한 input, output, effect, permission, evidence, failure contract를 가진 최소 재사용 행위다.**

Capability는 agent persona가 아니다. “Analyst”가 아니라 `spreadsheet.range.read`, `document.table.replace`, `web.search`, `repo.diff.inspect`처럼 검증 가능한 행위다.

## 2. Capability 유형

| 유형 | 설명 | 예시 |
|---|---|---|
| Reader | 상태를 읽고 구조화 | workbook inspect |
| Transformer | artifact를 다른 형태로 변환 | HWPX → PDF |
| Generator | 새 artifact 생성 | memo draft |
| Analyzer | 계산·분석 | variance analysis |
| Mutator | 상태 수정 | sheet range write |
| Connector | 외부 시스템 연결 | CRM record fetch |
| Verifier | 결과 검증 | formula audit |
| Orchestrator | 제한된 하위 Capability 조합 | monthly close pack |

Orchestrator가 Boulder Core lifecycle을 대체해서는 안 된다.

## 3. Capability manifest 필수 필드

```yaml
schema_version:
id:
version:
name:
description:
category:
stages:
interfaces:
inputs:
outputs:
effects:
permissions:
data_policy:
determinism:
evidence:
hooks:
dependencies:
compatibility:
provenance:
license:
trust:
```

구체 예시는 `schemas/capability-manifest.example.yaml`을 참조한다.

## 4. Hook contract

### `inspect`

설치 여부, runtime requirement, 지원 format, health를 반환한다. mutation 없음.

### `plan`

특정 invocation의 예상 input, output, effect, duration class, risk, required approval을 반환한다.

### `preview`

실제 실행 없이 diff, generated draft, command candidate, affected object를 보여준다.

### `execute`

승인된 scope 안에서 실행하고 artifact, evidence, effect receipt, error를 반환한다.

### `verify`

출력의 schema, fidelity, business rule, side effect를 확인한다.

### `rollback`

가능한 경우 실행 전 상태로 되돌리거나 recovery plan을 생성한다.

### `migrate`

manifest 또는 stored asset의 version migration을 수행한다.

모든 Capability가 모든 hook을 구현할 필요는 없지만, side effect가 있는 Capability는 최소 `preview`, `execute`, `verify`를 구현해야 한다. rollback 불가라면 명시해야 한다.

## 5. Invocation contract

```yaml
invocation:
  id:
  capability:
    id:
    version:
    adapter:
  inputs:
  context_refs:
  requested_effect:
  permission_scope:
  approval_ref:
  idempotency_key:
  timeout_policy:
  retry_policy:
  expected_outputs:
  evidence_requirements:
```

## 6. Result contract

```yaml
result:
  invocation_id:
  status:
  artifacts:
  evidence:
  telemetry:
  effect_receipt:
  warnings:
  errors:
  rollback:
  adapter_version:
  started_at:
  completed_at:
```

## 7. Permission과 데이터 정책

Capability manifest는 실행에 필요한 권한을 최소 단위로 선언한다.

```text
filesystem.read
filesystem.write
network.fetch
network.send
database.read
database.write
communication.send
finance.transact
identity.manage
```

데이터 class 예:

```text
public
internal
confidential
restricted
personal
regulated
```

Kit policy와 조직 policy는 Capability 요구 권한보다 더 엄격할 수 있다. Capability가 policy를 낮출 수는 없다.

## 8. Determinism

| 등급 | 의미 |
|---|---|
| deterministic | 같은 입력과 version이면 같은 output 기대 |
| bounded-nondeterministic | 허용 오차 또는 selection space가 명시됨 |
| agentic | model 판단이 포함되며 evidence와 critique 필요 |
| external-state-dependent | 외부 상태와 시점에 따라 결과가 변함 |

Critique와 replay는 determinism class에 따라 평가 방식을 바꾼다.

## 9. Registry와 Trust

### Registry가 저장하는 것

- ID와 version
- manifest
- source/provenance
- content hash/signature
- license
- publisher
- review status
- known vulnerabilities
- compatible Boulder contract
- supported environment
- test fixture
- deprecation
- usage telemetry opt-in

### Trust level

| 상태 | 의미 |
|---|---|
| unreviewed | source만 등록 |
| inspected | manifest와 package 구조 검사 |
| tested | official fixture 통과 |
| verified | maintainer 또는 공인 reviewer 검토 |
| organization-approved | 특정 조직 policy 통과 |
| blocked | security/license/policy 문제 |

현재 Boulder의 `configured-unverified` 개념은 이 trust lifecycle의 시작점으로 재사용할 수 있다.

## 10. Capability 설치 lifecycle

```text
discover
→ inspect manifest
→ resolve dependencies
→ evaluate trust/license
→ install or register
→ health check
→ enable for scope
→ bind to workflow
→ preview
→ execute
→ verify
→ monitor
→ upgrade/deprecate
```

초기 버전에서는 remote marketplace보다 **local manifest registry**를 우선한다.

## 11. Versioning

### Semantic contract

- Major: input/output/effect semantics breaking
- Minor: backward-compatible 기능 추가
- Patch: behavior 수정, security fix

### Compatibility matrix

Capability는 다음을 선언한다.

```yaml
compatibility:
  boulder_contract: ">=2.0.0 <3.0.0"
  runtime:
    node: ">=..."
    python: ">=..."
  platforms:
  formats:
```

Core는 runtime language를 강제하지 않고 process, WASI, MCP, local library, remote API adapter를 수용할 수 있어야 한다. 단, 각 transport는 동일한 result contract를 반환한다.

## 12. Test Harness

Capability package는 최소 fixture를 포함한다.

- valid input
- invalid input
- permission denied
- preview
- success
- partial failure
- retry/idempotency
- verification failure
- rollback 또는 rollback-unavailable
- sensitive data redaction

## 13. Compound와 Capability 승격

반복 workflow가 Capability 후보가 되려면 다음을 만족해야 한다.

- 서로 다른 run에서 반복됨
- input/output 경계가 안정적임
- domain-specific noun을 parameter 또는 Kit layer로 분리함
- effect와 permission이 정의됨
- failure가 관찰됨
- test fixture가 생성됨
- owner와 reviewer가 지정됨
- 기존 Capability와 중복 검사가 완료됨

Compound는 자동 publish하지 않는다. candidate를 생성하고 review queue에 넣는다.

## 14. Open-source 기여 모델

Capability contribution PR에는 다음이 포함돼야 한다.

- manifest
- source와 license
- threat/effect summary
- test fixture
- example invocation
- expected artifact
- verification
- maintenance owner
- deprecation policy

Core maintainer는 모든 Capability의 domain 품질을 보증하지 않는다. 대신 contract, safety, provenance, test 상태를 명확히 표시한다.


---

# Boulder Kit Model & Reference Capability Packs

## 1. Kit 정의

> **Kit는 특정 산업 또는 기능의 반복 업무를 실행하기 위해 workflow, policy, ontology, template, critique rubric과 Capability requirement를 조합한 설치 단위다.**

Kit는 Boulder fork가 아니다. Core를 import하되 Core가 Kit를 알지 못해야 한다.

## 2. Kit에 포함되는 것

```text
kit manifest
domain object schemas
workflow profiles
task templates
policy bundle
authority role suggestions
artifact templates
critique rubrics
recommended capabilities
onboarding interview
sample data / replay fixtures
dashboard definitions
migration scripts
documentation
```

`schemas/kit-manifest.example.yaml`에 초기 shape를 제안한다.

## 3. Capability Pack과 Kit의 차이

| 구분 | Capability Pack | Kit |
|---|---|---|
| 질문 | “무엇을 할 수 있는가?” | “이 업무를 어떻게 운영하는가?” |
| 범위 | tool/action | domain workflow |
| 예 | Spreadsheet Pack | VC Screening Kit |
| 재사용 | 여러 산업 | 특정 산업·기능 |
| policy | effect 중심 | business/authority 중심 |
| ontology | 거의 없음 | domain object 포함 |
| artifact | generic | domain template |

## 4. Universal Office Capability Pack

사용자가 명시한 Excel·한글 문서 기능은 Boulder Core가 아니라 **공용 Capability Pack**으로 설계한다.

```text
Office Pack
├─ Spreadsheet Pack
├─ Document Pack
├─ HWP/HWPX Pack
├─ PDF Pack
└─ Presentation Pack
```

각 Pack은 독립 release 가능하고 여러 adapter를 가질 수 있다.

## 5. Spreadsheet Pack 초안

### Capability family

```text
spreadsheet.workbook.inspect
spreadsheet.sheet.list
spreadsheet.range.read
spreadsheet.range.write
spreadsheet.formula.set
spreadsheet.formula.audit
spreadsheet.format.apply
spreadsheet.table.create
spreadsheet.chart.create
spreadsheet.named-range.manage
spreadsheet.data.validate
spreadsheet.workbook.diff
spreadsheet.workbook.recalculate
spreadsheet.workbook.export
spreadsheet.workbook.verify
```

### Plan 단계에서 보여줄 것

- 대상 workbook과 sheet
- 읽거나 바꿀 range
- formula와 value 변경
- format 변경
- 외부 link 영향
- recalculation 필요 여부
- 생성될 chart/table
- overwrite 위험
- backup/rollback 가능 여부

### Critique 단계

- formula error
- broken reference
- unexpected hardcode
- unit mismatch
- total/subtotal tie-out
- hidden sheet 영향
- workbook diff
- formatting consistency
- output schema와 template 준수

### Adapter 후보를 고르는 기준

초기 기획에서는 library를 확정하지 않는다. 다음 기준으로 prototype에서 선택한다.

- `.xlsx` fidelity
- formula 보존·계산
- chart/style 지원
- macro 처리와 보안
- cross-platform
- local-only 가능성
- license
- performance
- deterministic diff
- headless execution
- rollback

## 6. HWP/HWPX Pack 초안

HWP와 HWPX는 구현 난이도와 fidelity가 다를 수 있으므로 하나의 “한글 편집 기능”으로 뭉개지 않고 format driver를 분리한다.

### Capability family

```text
hwp.document.inspect
hwp.document.extract-text
hwp.document.extract-structure
hwp.document.replace-text
hwp.document.style.apply
hwp.document.table.read
hwp.document.table.write
hwp.document.image.insert
hwp.document.header-footer.edit
hwp.document.convert
hwp.document.diff
hwp.document.validate
```

### 단계적 가설

1. **Inspect / Extract MVP**  
   문서 구조와 text/table을 안전하게 읽는다.
2. **Template Fill MVP**  
   지정 placeholder와 table cell을 채운다.
3. **Controlled Edit MVP**  
   스타일과 layout 보존 범위가 명시된 편집.
4. **Conversion / Round-trip Test**  
   변환 후 손실을 Critique로 측정.
5. **Full-fidelity Driver 검토**  
   format, platform, license 조건이 확인된 뒤 결정.

### 반드시 검증할 risk

- format specification과 library license
- binary format round-trip fidelity
- font·layout 차이
- embedded object
- digital signature
- macro 또는 active content
- platform dependency
- 개인정보와 local processing 요구

“편집 가능”을 단일 boolean로 표시하지 않고 feature matrix와 fidelity grade를 제공한다.

## 7. Document / PDF / Presentation Pack

### Document

- paragraph/table/style
- template fill
- tracked diff
- metadata
- export
- structure validation

### PDF

- text/table extraction
- render
- merge/split
- annotation
- form fill
- provenance
- visual diff

### Presentation

- slide create/edit
- theme/layout
- chart/table
- speaker notes
- export
- visual QA

## 8. Reference Kit 1 — OSS Maintainer Kit

현재 Boulder의 핵심 vertical 기능을 추출한다.

### 포함

- repo inspection
- issue triage
- PR review prep
- release planning
- dependency review
- verification commands
- replay fixture
- Codex/GJC/LazyCodex presets
- product/service/release readiness
- contribution and security templates

### 사용하는 Capability

- repository
- shell/CI
- web/official docs
- document
- communication draft
- code analysis

이 Kit는 v1 compatibility를 보장하는 migration anchor다.

## 9. Reference Kit 2 — VC Screening Kit

### 대표 workflow

```text
Opportunity intake
→ evidence ingestion
→ company/entity resolution
→ mandate fit
→ financial normalization
→ preliminary valuation
→ risk scan
→ screening memo
→ independent challenge
→ human screening decision
```

### 필요한 Capability

- Document/PDF
- Spreadsheet
- Web Research
- Data Extraction
- Entity Resolution
- Financial Modeling
- Memo Generation
- Evidence/Citation
- Critique/Red Team

### Kit가 소유할 것

- Deal, Company, Fund 등 domain schema
- mandate policy
- screening memo template
- IC authority suggestion
- risk rubric
- evidence cutoff
- domain-specific hard failures

Core에는 이 noun을 추가하지 않는다.

## 10. Reference Kit 3 — Restaurant Ops Kit

### 대표 workflow

```text
Sales/import
→ inventory reconciliation
→ reorder proposal
→ supplier comparison
→ manager approval
→ purchase draft/order
→ receiving check
→ daily close report
→ recurring exception compound
```

### 필요한 Capability

- Spreadsheet
- POS/data connector
- Document
- Communication
- Scheduling
- Supplier web/API
- Notification
- Dashboard

### Kit가 소유할 것

- Menu Item, Ingredient, Supplier, Location, Shift
- reorder rule
- wastage policy
- manager authority
- daily close template
- food safety checklist
- exception threshold

## 11. 두-domain abstraction test

| 질문 | VC | Restaurant | Core 또는 공통 Pack |
|---|---|---|---|
| 입력 자료 수집 | CIM, financials | sales, inventory | Document/Spreadsheet |
| 계획 | screening plan | replenishment plan | Plan contract |
| 실행 | analysis, memo | reconcile, draft order | Capability runtime |
| critique | mandate/risk challenge | stock/price anomaly | Critique contract |
| human gate | screening decision | purchase approval | Authority |
| learning | recurring risk flag | recurring shortage | Compound |
| domain object | Deal, Fund | Ingredient, Shift | Kit-owned |
| common artifact | workbook, memo | workbook, report | Office Pack |

Core 수정 없이 두 workflow를 표현할 수 있어야 한다. 공통 기능이 반복되면 Capability Pack으로 올리고, domain rule이 섞이면 Kit에 남긴다.

## 12. Kit 설치 경험

```text
boulder kit inspect <kit>
boulder kit install <kit>
boulder kit doctor <kit>
boulder kit interview <kit>
boulder kit activate <kit>
boulder run <workflow>
```

초기 command 이름은 prototype이며 확정이 아니다.

설치 시 사용자에게 보여줄 것:

- Kit가 필요한 Capability
- data와 permission
- side-effect 범위
- human role
- unresolved dependency
- sample workflow
- trust/license
- local/remote execution
- compatibility


---

# Boulder Validation Strategy & MVP Roadmap

## 1. Roadmap 원칙

이번 재기획은 “큰 v2를 오래 만든 뒤 공개”하는 방식으로 진행하지 않는다.

각 milestone은 다음 세 가지를 동시에 증명해야 한다.

1. **Desirability:** 실제 사용자가 문제를 중요하게 여김
2. **Feasibility:** contract와 runtime으로 구현 가능
3. **Sustainability:** Core와 ecosystem을 유지할 수 있음

기능 완료가 아니라 **가설의 위험 제거**가 milestone의 목적이다.

## 2. Phase 0 — Hold, Inventory, Boundary Freeze

### 목표

현재 기능 추가를 잠시 멈추고 무엇을 보존할지 확정한다.

### 작업

- v0.1.x public contract 목록
- CLI output fixture
- package/file inventory
- architecture dependency map
- current user journey
- existing issue/PR 병목 분석
- Core 후보와 OSS Kit 후보 분류
- deprecation 금지 범위

### Exit Gate

- 기존 기능을 Keep / Generalize / Extract / Retire로 분류
- v1 compatibility test 존재
- 새 기능이 어느 layer에 들어갈지 판단 기준 합의

## 3. Phase 1 — Empathy & Problem Definition

### 목표

플랫폼 가설이 maintainer의 추론이 아니라 사용자 evidence에 기반하도록 한다.

### 작업

- 20명 이상 인터뷰·관찰
- operator journey map
- kit author journey
- capability developer journey
- trust/approval pain point
- repeated work inventory
- extreme user 포함

### Prototype

문서, storyboard, clickable/no-build prototype.

### Exit Gate

- 상위 5개 반복 Job
- 상위 5개 trust barrier
- 사용자 언어로 쓰인 product promise
- Plan preview와 Kit 설치 개념 이해도 확인

## 4. Phase 2 — Contract Kernel MVP

### 목표

도메인 없이 lifecycle을 machine-readable contract로 고정한다.

### 범위

- Intent
- Plan
- Step
- Artifact
- Evidence
- Effect
- Critique
- Authority Event
- Compound Candidate
- Workflow Profile
- versioning

### 구현

- schema validator
- state machine
- event ledger
- dry-run
- effect gate
- approval
- generic evaluator interface
- compatibility test

### Exit Gate

- invalid contract fail-closed
- unauthorized mutation 차단
- plan과 result diff 가능
- evaluator 교체 가능
- Kit noun 없이 runtime 실행 가능

## 5. Phase 3 — Capability SDK MVP

### 목표

제3자가 하나의 Capability를 구현하고 두 Kit에서 재사용할 수 있게 한다.

### 첫 vertical slice

Spreadsheet Pack:

```text
inspect → read → write preview → approve → execute → diff → verify
```

### 함께 구현할 것

- manifest
- local registry
- adapter resolution
- health check
- permission/effect
- fixture test harness
- compatibility
- install/enable/disable

### Exit Gate

- 내부 설명 없이 외부 개발자가 sample Capability 구현
- permission과 effect가 UI/CLI에 표시
- failed execution과 recovery 설명 가능
- 동일 Capability를 두 reference Kit가 사용

## 6. Phase 4 — Two-Domain Kit Prototype

### VC Slice

`intake → mandate fit → memo → challenge → human decision`

### Restaurant Slice

`sales/inventory → reorder proposal → manager approval → daily close`

### 검증 목적

- Core에 domain noun이 들어가지 않는가
- 같은 Spreadsheet/Document Capability를 재사용하는가
- authority와 critique가 다른 domain에서도 자연스러운가
- onboarding이 비개발자에게 이해되는가

### Exit Gate

- 두 Kit가 Core patch 없이 실행
- 공통 Capability fork 없음
- domain policy가 Kit 안에 유지
- 사용자별 first safe preview 15분 이내 목표를 검증
- 두 workflow의 evidence trace 완성

## 7. Phase 5 — Office Capability Pack

### 우선순위

1. Spreadsheet read/write/diff/verify
2. Document template fill/diff
3. PDF extraction/render/visual QA
4. HWP/HWPX inspect/extract/template fill
5. Presentation create/edit/QA

HWP full-fidelity edit는 format과 license 연구 결과에 따라 별도 gate를 둔다.

### Exit Gate

- feature matrix와 fidelity grade
- unsupported feature fail-closed
- round-trip test
- sample artifact 공개 가능
- license/provenance 기록

## 8. Phase 6 — Compound & Registry MVP

### 목표

반복 실행에서 검증된 자산을 발견하고 관리한다.

### 구현

- routine capture
- pattern clustering
- candidate generation
- candidate type classification
- human review
- promotion
- versioning
- effectiveness monitoring
- deprecation/archive

### Exit Gate

- candidate가 source run/evidence와 연결
- 자동 publish 없음
- duplicate detection
- 승격 후 실제 재사용 측정
- 효과가 낮은 asset을 rollback/deprecate 가능

## 9. Phase 7 — v1 Migration

### 전략

v1 command를 한 번에 제거하지 않는다.

```text
v1 CLI
→ compatibility adapter
→ v2 runtime
→ oss-maintainer-kit
```

### Migration slice

1. `profile resolve`
2. `handoff packet/review`
3. `verify`
4. `replay`
5. `routine/retro`
6. readiness commands

### Exit Gate

- 기존 fixture 결과와 명시된 차이만 발생
- migration guide
- deprecation timeline
- escape hatch
- current local workflow 유지

## 10. 핵심 측정 지표

### Activation

- 설치부터 first plan까지
- 설치부터 first safe preview까지
- unresolved dependency 해결률
- onboarding 질문 수

### Trust & Control

- effect declaration coverage
- approval bypass count
- user가 실행 전 영향 범위를 정확히 설명하는 비율
- rollback/recovery 성공률
- evidence coverage

### Platform Reuse

- Capability cross-kit reuse
- Kit 간 fork count
- Core change per new Kit
- adapter implementation effort
- contract-breaking change 수

### Quality

- critique issue precision/recall
- human override 이유
- repeat-run improvement
- artifact fidelity
- HWP/Spreadsheet round-trip defect

### Compound

- candidate acceptance rate
- 승격 asset 재사용률
- 재사용 후 시간/오류 감소
- stale/duplicate asset 비율

## 11. 초기 목표값은 “가설”로 관리

아래 숫자는 commitment가 아니라 prototype 목표다.

| Metric | 초기 목표 |
|---|---:|
| First safe preview | 15분 이내 |
| Side-effect declaration | 100% |
| Critical effect approval bypass | 0 |
| 두 Kit의 공통 Capability 재사용 | 3개 이상 |
| 새 Kit 추가 시 Core domain type 변경 | 0 |
| external developer sample Capability 구현 | 1 working day 이내 |
| Compound candidate source trace | 100% |

사용자 연구 결과에 따라 조정한다.

## 12. 주요 의사결정 Gate

### Gate A — Product Definition

한 줄 정의와 non-goal 승인.

### Gate B — Core Boundary

Core/Capability/Kit mapping 승인.

### Gate C — SDK Usability

외부 Capability prototype 통과.

### Gate D — Platform Generality

VC와 Restaurant 두-domain test 통과.

### Gate E — Office Pack Feasibility

Spreadsheet/HWP fidelity와 license 검증.

### Gate F — Migration

v1 compatibility와 deprecation 승인.

## 13. 중단 또는 재설계 조건

- 두 Kit를 지원하려면 Core에 지속적으로 domain noun을 추가해야 함
- Capability manifest가 실제 adapter 구현보다 복잡함
- preview/approval 때문에 반복 작업이 기존보다 느리고 신뢰도도 개선되지 않음
- Office Pack의 fidelity가 사용자 최소 요구를 충족하지 못함
- Compound candidate가 대부분 재사용되지 않음
- v1 migration 비용이 새 core 가치보다 큼
- maintainer가 trust/security review를 운영할 수 없음

실패 신호를 숨기지 않고 architecture decision의 입력으로 사용한다.


---

# Boulder Constitution — Draft 0.1

이 문서는 구현 상세가 아니라 Boulder가 장기적으로 지켜야 할 제품·아키텍처 원칙을 정의한다. 변경하려면 명시적 ADR, 사용자 영향, migration 계획과 검증 evidence가 필요하다.

## Article 1 — Boulder Serves Human Intent

Boulder의 목적은 인간의 의도를 대체하는 것이 아니라 명확하게 만들고 안전하게 실행하며 학습 가능하게 하는 것이다.

## Article 2 — The Public Lifecycle Is Stable

Boulder의 핵심 lifecycle은 다음이다.

```text
Plan → Execute → Critique → Compound
```

내부 lane은 발전할 수 있으나 public mental model을 불필요하게 깨지 않는다.

## Article 3 — Core Is Domain-Neutral

Core에는 VC의 Deal, Restaurant의 Ingredient, OSS의 Pull Request 같은 domain noun을 추가하지 않는다. Domain semantics는 Kit가 소유한다.

## Article 4 — Capabilities Are Replaceable

특정 model, agent, library, file engine, SaaS는 default adapter일 수 있지만 Core dependency가 아니다.

## Article 5 — Effects Must Be Declared

외부 세계나 상태를 바꾸는 모든 행위는 effect, scope, permission과 approval requirement를 선언한다.

## Article 6 — No Silent Mutation

사용자가 이해할 수 없는 방식으로 file, database, message, financial, identity 상태를 변경하지 않는다. 위험한 변경에는 preview와 명시적 gate가 필요하다.

## Article 7 — Evidence Precedes Claims

완료, 품질, readiness, 안전, 성능에 관한 주장은 검토 가능한 evidence와 연결돼야 한다.

## Article 8 — Critique Is Independently Routable

실행과 검토를 분리할 수 있어야 하며, hard failure는 평균 점수로 상쇄되지 않는다.

## Article 9 — Human Authority Is a First-Class Contract

Approve, reject, veto, override, delegate, sign과 같은 권한은 prompt가 아니라 구조화된 event와 policy로 표현한다.

## Article 10 — Compound Requires Review

반복 pattern을 자동으로 영구 자산으로 publish하지 않는다. evidence, generality, owner, test와 인간 검토를 거친다.

## Article 11 — Kits Compose; They Do Not Fork the Platform

Kit는 Core contract를 조합한다. Kit별 Core fork를 정상 확장 방식으로 인정하지 않는다.

## Article 12 — Capabilities Are Smaller Than Roles

Capability는 Analyst, Manager 같은 persona가 아니라 검증 가능한 행위와 interface로 정의한다.

## Article 13 — Local-First, Network-Explicit

가능한 workflow는 local-first로 실행하고 외부 전송·실행은 manifest와 plan에서 명시한다.

## Article 14 — Security Is a Contract Property

path safety, data classification, permission, provenance, trust, sandbox, rollback은 부가 기능이 아니라 Capability와 workflow의 필수 속성이다.

## Article 15 — Contracts Are Versioned

Public schema와 behavior는 version을 갖고 breaking change에는 migration과 deprecation 기간이 필요하다.

## Article 16 — Progressive Disclosure

초보 사용자는 Kit와 preview를 이해하면 되고, 전문가만 adapter와 policy 내부를 다룬다.

## Article 17 — Failure Must Be Legible

Blocked, partial, failed, waiting, manual handoff를 정상 상태로 표현한다. 실패를 success 문구 뒤에 숨기지 않는다.

## Article 18 — Open Source Includes Governance

source code뿐 아니라 contribution, review, trust, license, security disclosure, deprecation 절차를 공개한다.

## Article 19 — The Core Must Stay Smaller Than the Ecosystem

성공한 Boulder에서 대부분의 domain value는 Capability와 Kit에 존재해야 한다. Core 기능 수가 ecosystem보다 빠르게 늘면 경계를 재검토한다.

## Article 20 — Current Users Are Not Collateral Damage

재기획은 기존 사용자의 workflow와 evidence를 무시하지 않는다. v1 기능은 compatibility layer와 OSS Maintainer Kit를 통해 단계적으로 이동한다.

## Amendment Process

Constitution 변경 제안에는 다음이 필요하다.

```text
Problem
User evidence
Article affected
Proposed change
Rejected alternatives
Core/Capability/Kit impact
Security and migration impact
Prototype or fixture
Decision owner
Review period
```

긴급 security amendment를 제외하면 최소 한 번의 공개 review cycle을 거친다.


---

# Boulder Re-foundation — Decision Log, Risks & Open Questions

## 1. 현재 대화에서 승인된 방향

### D-001 — Boulder는 범용 플랫폼이다

Boulder는 VC나 OSS만을 위한 application이 아니라 여러 산업 Kit를 설치할 수 있는 open-source workflow platform으로 재정의한다.

### D-002 — Lifecycle은 Plan–Execute–Critique–Compound다

각 단계에는 복수 adapter를 연결할 수 있다. 단계는 고정된 vendor나 model을 의미하지 않는다.

### D-003 — Boulder와 AI-native GP는 분리한다

AI-native GP는 Boulder 위에 올라가는 Kit 또는 독립 domain project다. GP domain code를 Boulder core에 넣지 않는다.

### D-004 — Excel/HWP 기능은 공용 Capability Pack이다

Office 기능을 Core에 직접 넣지 않고 여러 산업 Kit가 공유하는 Capability Pack으로 만든다.

### D-005 — 현재 개발은 잠시 Hold하고 재기획한다

기능 추가보다 Design Intent, Core boundary, Capability SDK, Kit model을 먼저 확정한다.

### D-006 — 디자인 씽킹을 제품 개발 방식으로 적용한다

사용자 공감, 문제 정의, 다수 대안, 저비용 prototype, 실제 행동 기반 test를 통해 v2를 검증한다.

## 2. 제안 상태의 결정

### P-001 — 현 OSS 기능을 `oss-maintainer-kit`으로 추출

권고: 승인.

### P-002 — 두 reference Kit로 플랫폼성 검증

권고: `VC Screening`과 `Restaurant Ops`.

### P-003 — 초기 Registry는 local manifest

권고: hosted marketplace보다 먼저 구현.

### P-004 — Spreadsheet Pack을 첫 공용 Capability Pack으로 선택

권고: 승인. 읽기·쓰기·diff·verify를 한 vertical slice로 검증.

### P-005 — HWP는 단계적 fidelity strategy

권고: inspect/extract/template-fill부터 시작하고 full edit는 별도 feasibility gate.

### P-006 — v2는 Strangler migration

권고: 전면 rewrite보다 compatibility adapter를 사용.

## 3. 아직 결정하지 않은 질문

### Product / Brand

1. `Boulder` 이름을 platform 전체에 유지할 것인가?
2. Kit 명명 규칙은 `boulder-kit-*`인가?
3. “업무 플랫폼”, “workflow OS”, “agent workflow platform” 중 public language는 무엇인가?
4. Compound를 비개발자에게 어떤 단어로 설명할 것인가?

### Lifecycle

5. Critique는 항상 Execute 뒤에만 존재하는가, Plan Critique도 public하게 표현할 것인가?
6. Compound를 매 run에서 수행할지 batch/periodic으로 수행할지?
7. 장기 실행 workflow와 event-driven workflow를 v2 MVP에 포함할지?
8. 사람의 수동 step을 Capability처럼 표현할지 별도 Actor Task로 표현할지?

### SDK / Runtime

9. Capability transport의 최소 지원 범위는 process, library, MCP 중 무엇인가?
10. SDK reference language는 TypeScript 하나로 시작할지?
11. sandbox는 Core가 제공할지 deployment가 제공할지?
12. credential reference 표준은 어떻게 할지?
13. artifact storage는 file-first인지 pluggable store인지?
14. schema language는 JSON Schema 중심인지?
15. expression/policy language는 자체 DSL인지 기존 표준인지?

### Registry / Distribution

16. Capability와 Kit를 npm, Git, OCI 중 무엇으로 배포할지?
17. package signature와 publisher identity를 어떻게 검증할지?
18. community verified status의 reviewer는 누구인지?
19. telemetry는 opt-in인지 기본 local-only인지?
20. license incompatibility를 자동 차단할지 경고할지?

### Office Pack

21. `.xlsx` formula calculation을 누가 책임질지?
22. macro file을 지원할지?
23. HWP/HWPX 각각의 MVP fidelity 기준은 무엇인지?
24. font와 layout asset을 package에 포함할 수 있는지?
25. visual diff를 필수 Critique로 둘지?
26. Windows-only adapter를 허용할지?

### Experience

27. CLI-first 후 desktop인지, Capability SDK와 함께 desktop preview를 만들지?
28. nondeveloper onboarding interview를 Core가 제공할지 Kit가 제공할지?
29. multi-user approval UI는 언제 필요한지?
30. offline mode와 organization policy sync를 어떻게 병행할지?

### Governance

31. Core maintainer와 Kit maintainer 권한을 어떻게 나눌지?
32. Constitution amendment에 필요한 review 조건은?
33. security-sensitive Capability의 별도 review process는?
34. deprecated contract 지원 기간은?
35. official reference Kit 선정 기준은?

## 4. ADR Backlog

| ADR | 주제 | 우선순위 |
|---|---|---:|
| ADR-001 | Boulder Core / Capability / Kit boundary | P0 |
| ADR-002 | Public lifecycle와 internal lane | P0 |
| ADR-003 | Capability manifest v1 | P0 |
| ADR-004 | Effect and permission model | P0 |
| ADR-005 | Authority event model | P0 |
| ADR-006 | Artifact and evidence model | P0 |
| ADR-007 | Kit manifest v1 | P0 |
| ADR-008 | v1 compatibility and OSS Kit extraction | P0 |
| ADR-009 | Capability transport | P1 |
| ADR-010 | Registry and trust lifecycle | P1 |
| ADR-011 | Spreadsheet adapter strategy | P1 |
| ADR-012 | HWP/HWPX strategy | P1 |
| ADR-013 | Compound candidate promotion | P1 |
| ADR-014 | Local UI / desktop scope | P2 |
| ADR-015 | Hosted collaboration and marketplace | P3 |

## 5. Risk Register

| Risk | 가능성 | 영향 | 초기 대응 |
|---|---|---|---|
| 플랫폼 범위가 너무 넓음 | 높음 | 높음 | 두 vertical slice와 non-goal |
| SDK 설계가 실행보다 앞섬 | 높음 | 높음 | no-build → thin vertical slice |
| 현재 사용자 이탈 | 중간 | 높음 | v1 compatibility와 OSS Kit |
| Office fidelity 부족 | 중간 | 높음 | feature matrix와 fail-closed |
| Capability supply 부족 | 중간 | 높음 | first-party common packs |
| trust review 부담 | 중간 | 높음 | local registry, staged trust |
| Compound noise | 높음 | 중간 | human promotion gate |
| adapter ecosystem fragmentation | 중간 | 높음 | interface conformance test |
| Core 재비대화 | 높음 | 높음 | Constitution + dependency test |
| nondeveloper UX 지연 | 중간 | 높음 | Wizard-of-Oz early test |

## 6. 다음 회의의 권장 Agenda

1. Executive Brief의 한 줄 정의 승인
2. Constitution Article 2·3·4 승인
3. AS-IS Keep/Generalize/Extract/Retire 검토
4. Capability manifest 핵심 필드 토론
5. VC + Restaurant two-domain test 승인
6. Spreadsheet Pack MVP scope 승인
7. v1 Hold 범위와 migration owner 지정
8. 미결 질문 중 P0 ADR owner 지정
