# Sources & Evidence Map

## 1. Boulder 공식 저장소

검토 snapshot:

```text
min9lin9/boulder@10732cb0f3c1b5032ce4b2a542f8c514b658bd12
```

### 공식 파일

- `README.md` — 현재 제품 정의, CLI, profile/capability/handoff/routine surface
- `package.json` — package version, Bun/TypeScript stack, 배포 범위
- `boulder.yaml` — workflow stack, protected paths, provider policy, executor defaults
- `docs/WORKFLOW_ARCHITECTURE.md` — four domains, eight lanes, five verbs, adapter contract
- `docs/BOULDER_FINAL_PRODUCT_PLAN.md` — current product plan과 milestone
- `docs/OPERATOR_WORKFLOW_STACK.md` — workflow spine, review gate, compound learning layer
- `src/AGENTS.md` — source conventions, path safety, additive JSON contract
- `src/types.ts` — current profile, lane, manifest, verification type
- `src/workflow-profile-builtins.ts` — built-in purpose/profile와 adapter/model default
- `src/capability-source-schema.ts` — current capability source candidate contract

Repository:

- https://github.com/min9lin9/boulder

## 2. 디자인 씽킹 공식 자료

### Stanford d.school

- Design Thinking Bootleg  
  https://dschool.stanford.edu/tools/design-thinking-bootleg  
  Empathize, Define, Ideate, Prototype, Test의 다섯 mode와 유연한 활용.

- No-Build Hack  
  https://dschool.stanford.edu/tools/no-build-hack  
  고비용 구현 전에 맥락과 상호작용을 저비용 prototype으로 학습.

- Experiment Expedition  
  https://dschool.stanford.edu/tools/experiment-expedition  
  prototype, experiment, data capture, sense-making을 연결.

### IDEO / IDEO.org

- Design Thinking Introduction  
  https://designthinking.ideo.com/introduction  
  desirability, feasibility, viability의 균형.

- Human-Centered Design  
  https://www.designkit.org/human-centered-design.html  
  Inspiration, Ideation, Implementation과 사용자 중심 반복.

- Human-centered design vs. design thinking  
  https://designthinking.ideo.com/faq/whats-the-difference-between-human-centered-design-and-design-thinking  
  empathy, idea generation, prototype, sharing, implementation의 역할.

## 3. 문서에서 사실과 제안을 구분하는 방식

- **AS-IS 사실:** 공식 저장소 snapshot에서 확인
- **Design principle:** 현재 대화와 공식 design-thinking method를 바탕으로 제안
- **Architecture:** 검증 전 target hypothesis
- **숫자 목표:** commitment가 아니라 실험용 초기 목표
- **Excel/HWP 구현:** 특정 library를 아직 채택하지 않은 feasibility hypothesis

## 4. 추가 연구 필요

초기 기획 승인 후 다음은 각 공급자의 공식 문서와 format/license 자료만으로 별도 조사한다.

- Spreadsheet engine과 OOXML fidelity
- Microsoft Excel integration surface
- LibreOffice/headless integration surface
- HWP/HWPX format·SDK·license
- PDF rendering/visual diff
- package signing·OCI/npm/Git distribution
- sandbox와 WASI/process/MCP transport
