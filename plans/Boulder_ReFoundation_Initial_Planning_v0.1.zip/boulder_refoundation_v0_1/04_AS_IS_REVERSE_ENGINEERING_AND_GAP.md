# Boulder AS-IS Reverse Engineering & Platform Gap Review

## 1. 검토 범위와 한계

- 기준 저장소: `min9lin9/boulder@10732cb0f3c1b5032ce4b2a542f8c514b658bd12`
- 공개 package: `boulder-oss-cli@0.1.16`
- 검토한 공식 자료:
  - `README.md`
  - `package.json`
  - `boulder.yaml`
  - `docs/WORKFLOW_ARCHITECTURE.md`
  - `docs/BOULDER_FINAL_PRODUCT_PLAN.md`
  - `docs/OPERATOR_WORKFLOW_STACK.md`
  - `src/AGENTS.md`
  - `src/types.ts`
  - `src/workflow-profile-builtins.ts`
  - `src/capability-source-schema.ts`

이 문서는 초기 플랫폼 재기획을 위한 architecture review다. 전체 source를 line-by-line audit한 최종 reverse engineering report는 아니다.

## 2. 현재 제품 정의

현재 README와 package metadata는 Boulder를 **OSS repository를 evidence-backed Codex workflow로 만드는 operator kit**으로 정의한다. 사용자 표면은 `intake → plan → execute → verify → record`이며, 내부에는 `intake, plan, critic, handoff, execute, verify, compound, record` lane이 있다.

현재 구조의 핵심 의도는 이미 다음을 포함한다.

- planner와 executor를 replaceable adapter로 취급
- Boulder가 packet, handoff, verification, evidence, compound를 소유
- 외부 실행을 approval-gated로 제한
- local verification을 최종 기준으로 유지
- repeated routine을 학습 자산 후보로 축적

즉, **플랫폼의 씨앗은 존재한다.** 병목은 lifecycle 부재가 아니라 현재 contract와 product narrative가 OSS/Codex domain에 고정된 것이다.

## 3. 현재 코드 구조의 개념 지도

```text
CLI Surface
├─ init / inspect / quickstart
├─ profile
├─ capability import / doctor
├─ handoff
├─ verify / readiness / replay
├─ routine / retro / skill propose
└─ export

Core-ish Contracts
├─ BoulderManifest
├─ ResolvedWorkflowProfile
├─ LaneRoute
├─ ExternalPolicy
├─ Handoff Packet
├─ Run Event
└─ Readiness Check

Vertical Logic
├─ repository inspection
├─ PR / issue / release workflow assumptions
├─ GJC planning preference
├─ LazyCodex execution preference
├─ Codex capability inventory
└─ product/service/release readiness evidence
```

## 4. 유지할 강점

### Typed Record 중심

`src/AGENTS.md`는 class보다 plain function과 typed record를 선호하고, JSON contract의 additive evolution을 요구한다. Plugin SDK와 manifest 중심 플랫폼에 잘 맞는 규율이다.

### Side-effect-light command router

`cli.ts`가 domain logic을 직접 소유하지 않고 command module로 routing하도록 하는 원칙은 package 분리에 유리하다.

### Safe path/write posture

workspace containment, traversal·symlink·hardlink 방어, protected path, explicit error code는 향후 Capability sandbox의 좋은 토대다.

### Workflow Profile

현재 `ResolvedWorkflowProfile`은 stage별 owner, adapter, mode, evidence requirement, fallback을 표현한다. 범용 profile contract로 확장할 가치가 높다.

### External Policy

외부 실행은 기본 blocked, raw workspace content 금지, sanitized packet만 approval 이후 허용한다. 이 정책은 업종 일반의 effect model로 일반화 가능하다.

### Handoff Independence

planner와 executor를 packet으로 분리하고 review receipt를 요구하는 구조는 adapter 독립성과 human-in-the-loop에 유용하다.

### Readiness / Replay / Evidence

fixture와 evidence를 통해 “문서상 준비”와 “실행으로 증명된 준비”를 분리한 점은 Critique와 Compound에 중요한 기반이다.

### Routine / Retro

반복 task를 capture하고 review-first로 skill proposal 후보를 만드는 현재 loop는 Compound의 초기 구현으로 볼 수 있다.

## 5. 플랫폼화를 막는 결합

### 5.1 Product Definition Coupling

현재 정의는 `OSS repository`, `Codex`, `maintainer`, `release`를 제품 본체로 취급한다. 향후에는 이것들을 `oss-maintainer-kit`의 domain language로 내려야 한다.

### 5.2 Workflow Purpose가 닫혀 있음

현재 `WorkflowPurpose`는 다음 union이다.

```text
programming | research | ops | review | release
```

VC, restaurant, finance, document operations를 추가할 때 Core type을 수정해야 한다. 목적은 namespaced extension 또는 Kit-owned taxonomy가 돼야 한다.

### 5.3 Built-in Adapter와 Model Preference

`programming-default` profile은 GJC, LazyCodex, 특정 model preference를 직접 포함한다. 이는 좋은 default였지만 Core built-in이 아니라 Kit 또는 distribution preset으로 이동해야 한다.

### 5.4 Capability는 “후보 source”이지 Runtime Plugin이 아님

현재 capability manifest는 다음 정도를 표현한다.

- source
- kind: skill / adapter / agent-catalog
- trust status
- candidate command

하지만 실제 Capability SDK에 필요한 다음이 없다.

- input/output schema
- stage support
- effect·permission
- preview / execute / verify / rollback hook
- health check
- determinism
- evidence contract
- dependency와 compatibility
- artifact type
- data classification

### 5.5 Execute Contract가 Tool-neutral하지 않음

현재 execute는 주로 external executor candidate와 local Codex fallback을 routing한다. Excel range edit, HWP document transform, database query 같은 작은 typed action을 직접 표현하는 표준 interface가 필요하다.

### 5.6 Verification이 Repo Command 중심

현재 verification은 manifest의 shell command와 repo readiness에 최적화돼 있다. 범용 Critique는 schema validation, artifact diff, business rule, human review, adversarial check 등 다양한 evaluator를 지원해야 한다.

### 5.7 Compound가 Promotion System으로 완결되지 않음

현재 routine/retro/skill proposal은 좋은 시작이지만 다음이 없다.

- pattern similarity
- recurrence threshold와 confidence
- performance evidence
- candidate type 선택: template / workflow / capability / kit
- reviewer와 approval
- versioning·deprecation
- effectiveness monitoring

### 5.8 Kit라는 독립 배포 단위가 없음

현재 profile과 fixture가 domain package 역할을 일부 하지만, ontology, policy, template, workflow, recommended capabilities, dashboard, sample data, test를 하나의 Kit로 묶는 contract가 없다.

### 5.9 Human Authority가 External Send Approval로 축소됨

조직 업무에서는 approve, reject, veto, override, delegate, sign, dual control, conflict check가 필요하다. Core에 domain-specific committee를 넣지 않되 일반 Authority Event contract는 제공해야 한다.

## 6. Keep / Generalize / Extract / Retire

| 현재 자산 | 결정 | 목표 위치 |
|---|---|---|
| Workflow profile | **Generalize** | `packages/core-profile` |
| Lane routing | **Keep + Generalize** | lifecycle runtime |
| Handoff packet | **Generalize** | plan/execution artifact contract |
| Review receipt | **Generalize** | authority/effect gate |
| Protected paths / safe writes | **Keep** | capability sandbox |
| Run event / evidence | **Generalize** | event & evidence core |
| Readiness registry | **Generalize** | evaluator/gate registry |
| Replay fixture | **Generalize** | workflow test harness |
| Routine / retro | **Generalize** | compound engine |
| Capability source import | **Replace gradually** | capability registry client |
| GJC/LazyCodex defaults | **Extract** | `oss-maintainer-kit` preset |
| Repo inspection | **Extract** | OSS repository capability |
| Release/product/service readiness | **Extract** | `oss-maintainer-kit` policy |
| Codex-specific inventory | **Extract** | Codex environment pack |
| `boulder.yaml` legacy manifest | **Migrate** | compatibility loader |
| current CLI commands | **Wrap / Preserve** | v1 compatibility layer |

## 7. 권장 migration posture

### Rewrite가 아니라 Strangler

새 v2 core를 기존 코드 옆에 만들고 command별로 새 contract에 연결한다.

```text
Current CLI
   ├─ legacy command path
   └─ v2 compatibility adapter
           ↓
       Boulder Core v2
           ↓
   OSS Maintainer Kit
```

### 제안 package layout

```text
packages/
  core/
  contracts/
  runtime/
  policy/
  evidence/
  authority/
  capability-sdk/
  kit-sdk/
  registry/
  cli/

capabilities/
  repo/
  spreadsheet/
  document/
  hwp/
  web/

kits/
  oss-maintainer/
  vc-screening/
  restaurant-ops/
```

### 첫 추출 순서

1. Public type과 schema를 `contracts`로 이동
2. current profile loader를 v2 profile adapter로 감쌈
3. GJC/LazyCodex preference를 OSS Kit로 이동
4. readiness gate를 generic evaluator contract로 감쌈
5. repo-specific command를 capability로 이동
6. routine/retro를 compound candidate service로 일반화
7. v1 CLI의 output contract를 compatibility test로 고정

## 8. 기술적 위험

| 위험 | 영향 | 완화 |
|---|---|---|
| 지나친 추상화 | 사용자가 실제 가치를 못 느낌 | 두 reference Kit vertical slice |
| 기존 사용자 break | 신뢰 하락 | v1 compatibility layer와 fixture |
| Capability SDK 과대설계 | 개발 속도 저하 | 최소 hook부터 시작 |
| HWP format 난이도 | Office Pack 지연 | HWPX/convert/inspect 단계 분리 |
| Marketplace를 너무 일찍 구축 | 운영 부담 | local registry manifest부터 |
| Critique 비용·지연 | UX 저하 | risk-based reviewer routing |
| Compound 자산 쓰레기화 | 검색·신뢰 악화 | promotion gate와 usage telemetry |
| Domain leakage | Core 재비대화 | Constitution과 architecture test |

## 9. 초기 판단

현재 Boulder는 버릴 prototype이 아니다. 다음으로 재해석해야 한다.

> 현재 Boulder 0.1.x는 범용 플랫폼의 실패작이 아니라, **미래 Boulder Core가 지원해야 할 첫 번째 vertical Kit를 Core와 함께 구현한 상태**다.

따라서 재기획의 핵심은 기존 기능을 삭제하는 것이 아니라 **무엇이 Core이고 무엇이 OSS Maintainer Kit인지 분리하는 것**이다.
