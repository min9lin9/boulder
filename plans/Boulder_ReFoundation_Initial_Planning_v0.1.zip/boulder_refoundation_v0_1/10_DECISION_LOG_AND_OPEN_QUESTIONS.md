# Boulder Re-foundation — Decision Log, Risks & Open Questions

## 1. 현재 대화에서 승인된 방향

### D-001 — Boulder는 범용 플랫폼이다

Boulder는 VC나 OSS만을 위한 application이 아니라 여러 산업 Kit를 설치할 수 있는 open-source workflow platform으로 재정의한다.

### D-002 — Lifecycle은 Plan–Execute–Critique–Compound다

각 단계에는 복수 adapter를 연결할 수 있다. 단계는 고정된 vendor나 model을 의미하지 않는다.

### D-003 — Boulder와 AI-native GP는 분리한다

AI-native GP는 Boulder 위에 올라가는 Kit 또는 독립 domain project다. GP domain code를 Boulder core에 넣지 않는다.

### D-004 — Excel/HWP 기능은 공용 Capability Pack이다

Office 기능을 Core에 직접 넣지 않고 여러 산업 Kit가 공유하는 Capability Pack으로 만든다.

### D-005 — 현재 개발은 잠시 Hold하고 재기획한다

기능 추가보다 Design Intent, Core boundary, Capability SDK, Kit model을 먼저 확정한다.

### D-006 — 디자인 씽킹을 제품 개발 방식으로 적용한다

사용자 공감, 문제 정의, 다수 대안, 저비용 prototype, 실제 행동 기반 test를 통해 v2를 검증한다.

## 2. 제안 상태의 결정

### P-001 — 현 OSS 기능을 `oss-maintainer-kit`으로 추출

권고: 승인.

### P-002 — 두 reference Kit로 플랫폼성 검증

권고: `VC Screening`과 `Restaurant Ops`.

### P-003 — 초기 Registry는 local manifest

권고: hosted marketplace보다 먼저 구현.

### P-004 — Spreadsheet Pack을 첫 공용 Capability Pack으로 선택

권고: 승인. 읽기·쓰기·diff·verify를 한 vertical slice로 검증.

### P-005 — HWP는 단계적 fidelity strategy

권고: inspect/extract/template-fill부터 시작하고 full edit는 별도 feasibility gate.

### P-006 — v2는 Strangler migration

권고: 전면 rewrite보다 compatibility adapter를 사용.

## 3. 아직 결정하지 않은 질문

### Product / Brand

1. `Boulder` 이름을 platform 전체에 유지할 것인가?
2. Kit 명명 규칙은 `boulder-kit-*`인가?
3. “업무 플랫폼”, “workflow OS”, “agent workflow platform” 중 public language는 무엇인가?
4. Compound를 비개발자에게 어떤 단어로 설명할 것인가?

### Lifecycle

5. Critique는 항상 Execute 뒤에만 존재하는가, Plan Critique도 public하게 표현할 것인가?
6. Compound를 매 run에서 수행할지 batch/periodic으로 수행할지?
7. 장기 실행 workflow와 event-driven workflow를 v2 MVP에 포함할지?
8. 사람의 수동 step을 Capability처럼 표현할지 별도 Actor Task로 표현할지?

### SDK / Runtime

9. Capability transport의 최소 지원 범위는 process, library, MCP 중 무엇인가?
10. SDK reference language는 TypeScript 하나로 시작할지?
11. sandbox는 Core가 제공할지 deployment가 제공할지?
12. credential reference 표준은 어떻게 할지?
13. artifact storage는 file-first인지 pluggable store인지?
14. schema language는 JSON Schema 중심인지?
15. expression/policy language는 자체 DSL인지 기존 표준인지?

### Registry / Distribution

16. Capability와 Kit를 npm, Git, OCI 중 무엇으로 배포할지?
17. package signature와 publisher identity를 어떻게 검증할지?
18. community verified status의 reviewer는 누구인지?
19. telemetry는 opt-in인지 기본 local-only인지?
20. license incompatibility를 자동 차단할지 경고할지?

### Office Pack

21. `.xlsx` formula calculation을 누가 책임질지?
22. macro file을 지원할지?
23. HWP/HWPX 각각의 MVP fidelity 기준은 무엇인지?
24. font와 layout asset을 package에 포함할 수 있는지?
25. visual diff를 필수 Critique로 둘지?
26. Windows-only adapter를 허용할지?

### Experience

27. CLI-first 후 desktop인지, Capability SDK와 함께 desktop preview를 만들지?
28. nondeveloper onboarding interview를 Core가 제공할지 Kit가 제공할지?
29. multi-user approval UI는 언제 필요한지?
30. offline mode와 organization policy sync를 어떻게 병행할지?

### Governance

31. Core maintainer와 Kit maintainer 권한을 어떻게 나눌지?
32. Constitution amendment에 필요한 review 조건은?
33. security-sensitive Capability의 별도 review process는?
34. deprecated contract 지원 기간은?
35. official reference Kit 선정 기준은?

## 4. ADR Backlog

| ADR | 주제 | 우선순위 |
|---|---|---:|
| ADR-001 | Boulder Core / Capability / Kit boundary | P0 |
| ADR-002 | Public lifecycle와 internal lane | P0 |
| ADR-003 | Capability manifest v1 | P0 |
| ADR-004 | Effect and permission model | P0 |
| ADR-005 | Authority event model | P0 |
| ADR-006 | Artifact and evidence model | P0 |
| ADR-007 | Kit manifest v1 | P0 |
| ADR-008 | v1 compatibility and OSS Kit extraction | P0 |
| ADR-009 | Capability transport | P1 |
| ADR-010 | Registry and trust lifecycle | P1 |
| ADR-011 | Spreadsheet adapter strategy | P1 |
| ADR-012 | HWP/HWPX strategy | P1 |
| ADR-013 | Compound candidate promotion | P1 |
| ADR-014 | Local UI / desktop scope | P2 |
| ADR-015 | Hosted collaboration and marketplace | P3 |

## 5. Risk Register

| Risk | 가능성 | 영향 | 초기 대응 |
|---|---|---|---|
| 플랫폼 범위가 너무 넓음 | 높음 | 높음 | 두 vertical slice와 non-goal |
| SDK 설계가 실행보다 앞섬 | 높음 | 높음 | no-build → thin vertical slice |
| 현재 사용자 이탈 | 중간 | 높음 | v1 compatibility와 OSS Kit |
| Office fidelity 부족 | 중간 | 높음 | feature matrix와 fail-closed |
| Capability supply 부족 | 중간 | 높음 | first-party common packs |
| trust review 부담 | 중간 | 높음 | local registry, staged trust |
| Compound noise | 높음 | 중간 | human promotion gate |
| adapter ecosystem fragmentation | 중간 | 높음 | interface conformance test |
| Core 재비대화 | 높음 | 높음 | Constitution + dependency test |
| nondeveloper UX 지연 | 중간 | 높음 | Wizard-of-Oz early test |

## 6. 다음 회의의 권장 Agenda

1. Executive Brief의 한 줄 정의 승인
2. Constitution Article 2·3·4 승인
3. AS-IS Keep/Generalize/Extract/Retire 검토
4. Capability manifest 핵심 필드 토론
5. VC + Restaurant two-domain test 승인
6. Spreadsheet Pack MVP scope 승인
7. v1 Hold 범위와 migration owner 지정
8. 미결 질문 중 P0 ADR owner 지정
