# Boulder Design Intent & Product Principles

## 1. Design Intent

Boulder가 해결하려는 본질적인 문제는 “AI가 일을 못한다”가 아니다.

사람과 조직의 업무는 다음 이유로 반복 가능하게 만들기 어렵다.

- 의도와 성공 기준이 암묵적이다.
- 업무가 여러 tool과 사람 사이에서 끊긴다.
- 실행 권한과 책임이 불명확하다.
- 결과는 남지만 판단 근거와 실패 과정은 사라진다.
- 반복되는 작업을 발견해도 재사용 가능한 형태로 승격되지 않는다.
- 산업별 software는 깊지만 폐쇄적이고, 범용 agent는 넓지만 맥락이 얕다.

Boulder의 Design Intent는 이 간극을 메우는 것이다.

> **사람의 암묵적 업무를 설명 가능하고 조합 가능하며 검증 가능하고 학습 가능한 운영 자산으로 바꾼다.**

## 2. Product Mental Model

```mermaid
flowchart LR
    U[Intent] --> P[Plan]
    P --> X[Execute]
    X --> C[Critique]
    C -->|Revise| P
    C -->|Accept| M[Compound]
    M --> A[Reusable Asset]
    A --> P

    E[Evidence] -.-> P
    E -.-> C
    H[Human Authority] -.-> P
    H -.-> X
    H -.-> C
    Y[Policy] -.-> P
    Y -.-> X
    Y -.-> C
```

### Plan

“무엇을 할까?”가 아니라 다음을 구조화한다.

- 목표
- scope와 non-goal
- context와 evidence
- task graph
- 사용할 Capability와 version
- 예상 side effect
- approval point
- acceptance criteria
- fallback과 recovery

### Execute

Plan을 자의적으로 재해석하지 않고 contract에 따라 행위를 수행한다.

- deterministic step과 agentic step을 구분
- 실행 전 preview 제공
- effect scope 제한
- artifact·telemetry·error 기록
- partial failure와 retry를 명시
- 승인되지 않은 외부 effect 차단

### Critique

Execute의 부속 검사가 아니라 독립적인 판단 단계다.

- 결과 정확성
- 근거 충실성
- 정책 준수
- 사용자 의도 적합성
- 형식·품질
- side-effect 검증
- 반대 관점 또는 red-team
- 재실행·수정·승인·거절 결정

### Compound

과거를 저장하는 것이 아니라 미래의 비용을 줄이는 학습 단계다.

- 반복 task 발견
- 안정적인 plan pattern 발견
- 재사용 가능한 prompt/template/schema 추출
- failure mode와 recovery rule 축적
- Capability 또는 Kit 후보 생성
- 인간 검토 후 승격
- 효과가 없는 asset은 폐기 또는 archive

## 3. 제품 층

| 층 | 책임 |
|---|---|
| **Boulder Core** | lifecycle, contracts, policy, evidence, authority, event state |
| **Capability SDK** | 재사용 행위의 표준 interface |
| **Capability Pack** | 관련 Capability 묶음 |
| **Kit SDK** | domain workflow·policy·template·ontology 조합 |
| **Experience Layer** | CLI, desktop, API, MCP, web UI |
| **Registry / Trust Layer** | discovery, version, provenance, license, review status |

## 4. Design Principles

### 1. Human Intent Before Automation

자동화 수준보다 의도와 책임의 명확성을 우선한다.

### 2. Small Core, Rich Edges

산업 지식과 tool-specific logic은 Capability와 Kit에 둔다. Core는 lifecycle contract만 소유한다.

### 3. Everything Important Is a Contract

input, output, effect, permission, evidence, failure, version을 구조화한다. 중요한 행동을 prompt 관습에 의존하지 않는다.

### 4. Preview Before Mutation

write, send, publish, pay, delete, sign 같은 행위는 preview와 policy evaluation을 거친다.

### 5. Evidence Is a First-Class Object

결과뿐 아니라 어떤 evidence와 version으로 판단했는지 연결한다.

### 6. Critique Must Be Independently Routable

같은 adapter가 실행과 검토를 모두 할 수는 있지만, 사용자가 별도 reviewer를 연결하고 독립 context를 강제할 수 있어야 한다.

### 7. Compound Is Earned, Not Automatic

반복됐다는 이유만으로 asset을 만들지 않는다. 안정성, 재사용성, evidence, 인간 검토를 통과해야 한다.

### 8. Capabilities Compose; Kits Orchestrate

Capability는 작은 재사용 행위이고, Kit는 domain 의미를 가진 조합이다. Kit가 저수준 integration을 복제하지 않는다.

### 9. Domain Knowledge Never Leaks Into Core

VC의 Deal, Restaurant의 Menu, OSS의 Pull Request는 Core type이 아니다. Kit schema로 정의한다.

### 10. Provider-Neutral, Environment-Aware

특정 model, agent, office suite, SaaS는 adapter 기본값일 수 있지만 Core dependency가 아니다.

### 11. Local-First, Network-Explicit

로컬 실행과 데이터 경계를 기본값으로 삼고 외부 전송은 명시적으로 선언·승인한다.

### 12. Safe Failure Is a Product Feature

부분 실패, retry, rollback, manual handoff를 정상적인 workflow 상태로 다룬다.

### 13. Progressive Disclosure

비개발자는 Kit 설치와 preview만 보아도 되고, 전문가만 lane·policy·schema를 내려다본다.

### 14. Versioned and Inspectable

모든 public contract는 version을 갖고 diff와 compatibility를 설명한다.

### 15. Open Source Means Extensible Governance

코드 공개만으로 충분하지 않다. contribution, trust, license, deprecation, security review 절차도 공개한다.

## 5. Non-goals

Boulder는 다음이 아니다.

- 범용 office suite
- 모든 산업을 내장한 monolith
- 완전 자율 swarm runtime
- 특정 LLM의 wrapper
- 단순 prompt library
- scheduler만 제공하는 automation tool
- benchmark leaderboard
- credential vault
- 규제 산업의 최종 책임자
- domain Kit의 business logic을 대신 소유하는 플랫폼

## 6. 용어

| 용어 | 의미 |
|---|---|
| Intent | 사용자의 목표와 맥락 |
| Workflow | lifecycle 안에서 수행되는 task graph |
| Stage | Plan, Execute, Critique, Compound |
| Lane | stage 내부의 세부 routing boundary |
| Capability | 계약을 가진 최소 재사용 행위 |
| Adapter | Capability를 특정 library/API/runtime으로 구현한 것 |
| Pack | 관련 Capability의 배포 묶음 |
| Kit | 특정 domain의 workflow·policy·template·ontology 묶음 |
| Artifact | 실행이 만든 결과물 |
| Evidence | 주장이나 평가를 뒷받침하는 근거 |
| Effect | 외부 세계나 상태에 미치는 영향 |
| Gate | transition을 허용·차단하는 조건 |
| Compound Candidate | 재사용 자산으로 승격을 검토 중인 패턴 |

## 7. 정체성 검증 질문

새 기능을 Core에 넣기 전에 묻는다.

1. 두 개 이상의 서로 다른 Kit에서 필요한가?
2. 독립 input/output과 failure semantics가 있는가?
3. Capability로 외부 배포할 수 없는 이유가 있는가?
4. domain object를 Core에 새로 추가하지 않고 표현할 수 있는가?
5. 이 기능이 Plan, Execute, Critique, Compound 중 어디에 속하는가?
6. side effect와 evidence를 명확히 선언할 수 있는가?
7. 제거해도 기존 public contract가 유지되는가?

답이 불명확하면 Core에 넣지 않는다.
