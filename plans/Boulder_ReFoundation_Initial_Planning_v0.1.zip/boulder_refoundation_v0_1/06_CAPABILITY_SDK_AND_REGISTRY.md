# Boulder Capability SDK & Registry Initial Specification

## 1. Capability 정의

> **Capability는 명확한 input, output, effect, permission, evidence, failure contract를 가진 최소 재사용 행위다.**

Capability는 agent persona가 아니다. “Analyst”가 아니라 `spreadsheet.range.read`, `document.table.replace`, `web.search`, `repo.diff.inspect`처럼 검증 가능한 행위다.

## 2. Capability 유형

| 유형 | 설명 | 예시 |
|---|---|---|
| Reader | 상태를 읽고 구조화 | workbook inspect |
| Transformer | artifact를 다른 형태로 변환 | HWPX → PDF |
| Generator | 새 artifact 생성 | memo draft |
| Analyzer | 계산·분석 | variance analysis |
| Mutator | 상태 수정 | sheet range write |
| Connector | 외부 시스템 연결 | CRM record fetch |
| Verifier | 결과 검증 | formula audit |
| Orchestrator | 제한된 하위 Capability 조합 | monthly close pack |

Orchestrator가 Boulder Core lifecycle을 대체해서는 안 된다.

## 3. Capability manifest 필수 필드

```yaml
schema_version:
id:
version:
name:
description:
category:
stages:
interfaces:
inputs:
outputs:
effects:
permissions:
data_policy:
determinism:
evidence:
hooks:
dependencies:
compatibility:
provenance:
license:
trust:
```

구체 예시는 `schemas/capability-manifest.example.yaml`을 참조한다.

## 4. Hook contract

### `inspect`

설치 여부, runtime requirement, 지원 format, health를 반환한다. mutation 없음.

### `plan`

특정 invocation의 예상 input, output, effect, duration class, risk, required approval을 반환한다.

### `preview`

실제 실행 없이 diff, generated draft, command candidate, affected object를 보여준다.

### `execute`

승인된 scope 안에서 실행하고 artifact, evidence, effect receipt, error를 반환한다.

### `verify`

출력의 schema, fidelity, business rule, side effect를 확인한다.

### `rollback`

가능한 경우 실행 전 상태로 되돌리거나 recovery plan을 생성한다.

### `migrate`

manifest 또는 stored asset의 version migration을 수행한다.

모든 Capability가 모든 hook을 구현할 필요는 없지만, side effect가 있는 Capability는 최소 `preview`, `execute`, `verify`를 구현해야 한다. rollback 불가라면 명시해야 한다.

## 5. Invocation contract

```yaml
invocation:
  id:
  capability:
    id:
    version:
    adapter:
  inputs:
  context_refs:
  requested_effect:
  permission_scope:
  approval_ref:
  idempotency_key:
  timeout_policy:
  retry_policy:
  expected_outputs:
  evidence_requirements:
```

## 6. Result contract

```yaml
result:
  invocation_id:
  status:
  artifacts:
  evidence:
  telemetry:
  effect_receipt:
  warnings:
  errors:
  rollback:
  adapter_version:
  started_at:
  completed_at:
```

## 7. Permission과 데이터 정책

Capability manifest는 실행에 필요한 권한을 최소 단위로 선언한다.

```text
filesystem.read
filesystem.write
network.fetch
network.send
database.read
database.write
communication.send
finance.transact
identity.manage
```

데이터 class 예:

```text
public
internal
confidential
restricted
personal
regulated
```

Kit policy와 조직 policy는 Capability 요구 권한보다 더 엄격할 수 있다. Capability가 policy를 낮출 수는 없다.

## 8. Determinism

| 등급 | 의미 |
|---|---|
| deterministic | 같은 입력과 version이면 같은 output 기대 |
| bounded-nondeterministic | 허용 오차 또는 selection space가 명시됨 |
| agentic | model 판단이 포함되며 evidence와 critique 필요 |
| external-state-dependent | 외부 상태와 시점에 따라 결과가 변함 |

Critique와 replay는 determinism class에 따라 평가 방식을 바꾼다.

## 9. Registry와 Trust

### Registry가 저장하는 것

- ID와 version
- manifest
- source/provenance
- content hash/signature
- license
- publisher
- review status
- known vulnerabilities
- compatible Boulder contract
- supported environment
- test fixture
- deprecation
- usage telemetry opt-in

### Trust level

| 상태 | 의미 |
|---|---|
| unreviewed | source만 등록 |
| inspected | manifest와 package 구조 검사 |
| tested | official fixture 통과 |
| verified | maintainer 또는 공인 reviewer 검토 |
| organization-approved | 특정 조직 policy 통과 |
| blocked | security/license/policy 문제 |

현재 Boulder의 `configured-unverified` 개념은 이 trust lifecycle의 시작점으로 재사용할 수 있다.

## 10. Capability 설치 lifecycle

```text
discover
→ inspect manifest
→ resolve dependencies
→ evaluate trust/license
→ install or register
→ health check
→ enable for scope
→ bind to workflow
→ preview
→ execute
→ verify
→ monitor
→ upgrade/deprecate
```

초기 버전에서는 remote marketplace보다 **local manifest registry**를 우선한다.

## 11. Versioning

### Semantic contract

- Major: input/output/effect semantics breaking
- Minor: backward-compatible 기능 추가
- Patch: behavior 수정, security fix

### Compatibility matrix

Capability는 다음을 선언한다.

```yaml
compatibility:
  boulder_contract: ">=2.0.0 <3.0.0"
  runtime:
    node: ">=..."
    python: ">=..."
  platforms:
  formats:
```

Core는 runtime language를 강제하지 않고 process, WASI, MCP, local library, remote API adapter를 수용할 수 있어야 한다. 단, 각 transport는 동일한 result contract를 반환한다.

## 12. Test Harness

Capability package는 최소 fixture를 포함한다.

- valid input
- invalid input
- permission denied
- preview
- success
- partial failure
- retry/idempotency
- verification failure
- rollback 또는 rollback-unavailable
- sensitive data redaction

## 13. Compound와 Capability 승격

반복 workflow가 Capability 후보가 되려면 다음을 만족해야 한다.

- 서로 다른 run에서 반복됨
- input/output 경계가 안정적임
- domain-specific noun을 parameter 또는 Kit layer로 분리함
- effect와 permission이 정의됨
- failure가 관찰됨
- test fixture가 생성됨
- owner와 reviewer가 지정됨
- 기존 Capability와 중복 검사가 완료됨

Compound는 자동 publish하지 않는다. candidate를 생성하고 review queue에 넣는다.

## 14. Open-source 기여 모델

Capability contribution PR에는 다음이 포함돼야 한다.

- manifest
- source와 license
- threat/effect summary
- test fixture
- example invocation
- expected artifact
- verification
- maintenance owner
- deprecation policy

Core maintainer는 모든 Capability의 domain 품질을 보증하지 않는다. 대신 contract, safety, provenance, test 상태를 명확히 표시한다.
