# Boulder Validation Strategy & MVP Roadmap

## 1. Roadmap 원칙

이번 재기획은 “큰 v2를 오래 만든 뒤 공개”하는 방식으로 진행하지 않는다.

각 milestone은 다음 세 가지를 동시에 증명해야 한다.

1. **Desirability:** 실제 사용자가 문제를 중요하게 여김
2. **Feasibility:** contract와 runtime으로 구현 가능
3. **Sustainability:** Core와 ecosystem을 유지할 수 있음

기능 완료가 아니라 **가설의 위험 제거**가 milestone의 목적이다.

## 2. Phase 0 — Hold, Inventory, Boundary Freeze

### 목표

현재 기능 추가를 잠시 멈추고 무엇을 보존할지 확정한다.

### 작업

- v0.1.x public contract 목록
- CLI output fixture
- package/file inventory
- architecture dependency map
- current user journey
- existing issue/PR 병목 분석
- Core 후보와 OSS Kit 후보 분류
- deprecation 금지 범위

### Exit Gate

- 기존 기능을 Keep / Generalize / Extract / Retire로 분류
- v1 compatibility test 존재
- 새 기능이 어느 layer에 들어갈지 판단 기준 합의

## 3. Phase 1 — Empathy & Problem Definition

### 목표

플랫폼 가설이 maintainer의 추론이 아니라 사용자 evidence에 기반하도록 한다.

### 작업

- 20명 이상 인터뷰·관찰
- operator journey map
- kit author journey
- capability developer journey
- trust/approval pain point
- repeated work inventory
- extreme user 포함

### Prototype

문서, storyboard, clickable/no-build prototype.

### Exit Gate

- 상위 5개 반복 Job
- 상위 5개 trust barrier
- 사용자 언어로 쓰인 product promise
- Plan preview와 Kit 설치 개념 이해도 확인

## 4. Phase 2 — Contract Kernel MVP

### 목표

도메인 없이 lifecycle을 machine-readable contract로 고정한다.

### 범위

- Intent
- Plan
- Step
- Artifact
- Evidence
- Effect
- Critique
- Authority Event
- Compound Candidate
- Workflow Profile
- versioning

### 구현

- schema validator
- state machine
- event ledger
- dry-run
- effect gate
- approval
- generic evaluator interface
- compatibility test

### Exit Gate

- invalid contract fail-closed
- unauthorized mutation 차단
- plan과 result diff 가능
- evaluator 교체 가능
- Kit noun 없이 runtime 실행 가능

## 5. Phase 3 — Capability SDK MVP

### 목표

제3자가 하나의 Capability를 구현하고 두 Kit에서 재사용할 수 있게 한다.

### 첫 vertical slice

Spreadsheet Pack:

```text
inspect → read → write preview → approve → execute → diff → verify
```

### 함께 구현할 것

- manifest
- local registry
- adapter resolution
- health check
- permission/effect
- fixture test harness
- compatibility
- install/enable/disable

### Exit Gate

- 내부 설명 없이 외부 개발자가 sample Capability 구현
- permission과 effect가 UI/CLI에 표시
- failed execution과 recovery 설명 가능
- 동일 Capability를 두 reference Kit가 사용

## 6. Phase 4 — Two-Domain Kit Prototype

### VC Slice

`intake → mandate fit → memo → challenge → human decision`

### Restaurant Slice

`sales/inventory → reorder proposal → manager approval → daily close`

### 검증 목적

- Core에 domain noun이 들어가지 않는가
- 같은 Spreadsheet/Document Capability를 재사용하는가
- authority와 critique가 다른 domain에서도 자연스러운가
- onboarding이 비개발자에게 이해되는가

### Exit Gate

- 두 Kit가 Core patch 없이 실행
- 공통 Capability fork 없음
- domain policy가 Kit 안에 유지
- 사용자별 first safe preview 15분 이내 목표를 검증
- 두 workflow의 evidence trace 완성

## 7. Phase 5 — Office Capability Pack

### 우선순위

1. Spreadsheet read/write/diff/verify
2. Document template fill/diff
3. PDF extraction/render/visual QA
4. HWP/HWPX inspect/extract/template fill
5. Presentation create/edit/QA

HWP full-fidelity edit는 format과 license 연구 결과에 따라 별도 gate를 둔다.

### Exit Gate

- feature matrix와 fidelity grade
- unsupported feature fail-closed
- round-trip test
- sample artifact 공개 가능
- license/provenance 기록

## 8. Phase 6 — Compound & Registry MVP

### 목표

반복 실행에서 검증된 자산을 발견하고 관리한다.

### 구현

- routine capture
- pattern clustering
- candidate generation
- candidate type classification
- human review
- promotion
- versioning
- effectiveness monitoring
- deprecation/archive

### Exit Gate

- candidate가 source run/evidence와 연결
- 자동 publish 없음
- duplicate detection
- 승격 후 실제 재사용 측정
- 효과가 낮은 asset을 rollback/deprecate 가능

## 9. Phase 7 — v1 Migration

### 전략

v1 command를 한 번에 제거하지 않는다.

```text
v1 CLI
→ compatibility adapter
→ v2 runtime
→ oss-maintainer-kit
```

### Migration slice

1. `profile resolve`
2. `handoff packet/review`
3. `verify`
4. `replay`
5. `routine/retro`
6. readiness commands

### Exit Gate

- 기존 fixture 결과와 명시된 차이만 발생
- migration guide
- deprecation timeline
- escape hatch
- current local workflow 유지

## 10. 핵심 측정 지표

### Activation

- 설치부터 first plan까지
- 설치부터 first safe preview까지
- unresolved dependency 해결률
- onboarding 질문 수

### Trust & Control

- effect declaration coverage
- approval bypass count
- user가 실행 전 영향 범위를 정확히 설명하는 비율
- rollback/recovery 성공률
- evidence coverage

### Platform Reuse

- Capability cross-kit reuse
- Kit 간 fork count
- Core change per new Kit
- adapter implementation effort
- contract-breaking change 수

### Quality

- critique issue precision/recall
- human override 이유
- repeat-run improvement
- artifact fidelity
- HWP/Spreadsheet round-trip defect

### Compound

- candidate acceptance rate
- 승격 asset 재사용률
- 재사용 후 시간/오류 감소
- stale/duplicate asset 비율

## 11. 초기 목표값은 “가설”로 관리

아래 숫자는 commitment가 아니라 prototype 목표다.

| Metric | 초기 목표 |
|---|---:|
| First safe preview | 15분 이내 |
| Side-effect declaration | 100% |
| Critical effect approval bypass | 0 |
| 두 Kit의 공통 Capability 재사용 | 3개 이상 |
| 새 Kit 추가 시 Core domain type 변경 | 0 |
| external developer sample Capability 구현 | 1 working day 이내 |
| Compound candidate source trace | 100% |

사용자 연구 결과에 따라 조정한다.

## 12. 주요 의사결정 Gate

### Gate A — Product Definition

한 줄 정의와 non-goal 승인.

### Gate B — Core Boundary

Core/Capability/Kit mapping 승인.

### Gate C — SDK Usability

외부 Capability prototype 통과.

### Gate D — Platform Generality

VC와 Restaurant 두-domain test 통과.

### Gate E — Office Pack Feasibility

Spreadsheet/HWP fidelity와 license 검증.

### Gate F — Migration

v1 compatibility와 deprecation 승인.

## 13. 중단 또는 재설계 조건

- 두 Kit를 지원하려면 Core에 지속적으로 domain noun을 추가해야 함
- Capability manifest가 실제 adapter 구현보다 복잡함
- preview/approval 때문에 반복 작업이 기존보다 느리고 신뢰도도 개선되지 않음
- Office Pack의 fidelity가 사용자 최소 요구를 충족하지 못함
- Compound candidate가 대부분 재사용되지 않음
- v1 migration 비용이 새 core 가치보다 큼
- maintainer가 trust/security review를 운영할 수 없음

실패 신호를 숨기지 않고 architecture decision의 입력으로 사용한다.
