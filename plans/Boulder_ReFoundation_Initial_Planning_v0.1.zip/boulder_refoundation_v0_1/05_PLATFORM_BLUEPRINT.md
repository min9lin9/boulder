# Boulder Platform Blueprint v0.1

## 1. 목표 구조

```mermaid
flowchart TB
    subgraph Experience["Experience Layer"]
      CLI[CLI]
      UI[Desktop / Web UI]
      API[API / MCP]
    end

    subgraph Kits["Kit Layer"]
      OSS[OSS Maintainer Kit]
      VC[VC Kit]
      REST[Restaurant Ops Kit]
      OTHER[Other Kits]
    end

    subgraph Packs["Capability Packs"]
      SHEET[Spreadsheet Pack]
      DOC[Document Pack]
      HWP[HWP/HWPX Pack]
      WEB[Web & Research Pack]
      DATA[Data / DB Pack]
      COMM[Communication Pack]
    end

    subgraph Platform["Boulder Platform"]
      KITSDK[Kit SDK]
      CAPSDK[Capability SDK]
      REG[Registry & Resolver]
      CORE[Plan–Execute–Critique–Compound Runtime]
      POLICY[Policy & Authority]
      EVID[Evidence / Artifact / Event Ledger]
      SANDBOX[Effect Gate & Sandbox]
    end

    Experience --> Kits
    Kits --> Packs
    Kits --> KITSDK
    Packs --> CAPSDK
    KITSDK --> CORE
    CAPSDK --> CORE
    CORE --> POLICY
    CORE --> EVID
    CORE --> SANDBOX
    REG --> KITSDK
    REG --> CAPSDK
```

## 2. Core가 소유하는 최소 객체

### Intent

사용자가 원하는 outcome과 context. 원문 입력을 보존하되 normalized objective를 별도로 생성한다.

### Work Context

참고 data, environment, actor, policy scope, installed capability snapshot.

### Plan

task graph, capability binding, effect, gate, acceptance, fallback을 포함한 실행 계약.

### Step

Plan 안의 최소 실행 노드. 하나 이상의 Capability invocation을 포함할 수 있다.

### Artifact

실행 결과물. file, record, message draft, report, decision package 등.

### Evidence

Artifact나 평가를 뒷받침하는 source와 provenance.

### Critique

criterion별 평가, issue, severity, confidence, recommended transition.

### Decision / Authority Event

사람 또는 승인된 시스템이 transition을 허용·차단·override한 기록.

### Compound Candidate

반복 pattern을 재사용 자산으로 승격하기 위한 후보.

## 3. Public lifecycle contract

### Plan Contract

#### 입력

- intent
- actor와 authority scope
- context references
- Kit workflow/profile
- installed Capability inventory
- policy snapshot

#### 출력

- objective와 scope
- task graph
- capability requirements
- selected adapters
- expected artifact
- effect summary
- approval gates
- acceptance criteria
- critique strategy
- fallback/recovery
- evidence requirements

#### 불변조건

- 모든 step은 입력과 출력 schema를 가진다.
- 모든 side effect는 선언된다.
- 승인 전 mutation step은 실행 가능 상태가 아니다.
- binding되지 않은 Capability가 있으면 plan은 `unresolved`다.

### Execute Contract

#### 입력

- sealed 또는 approved plan
- step
- capability binding
- scoped credentials/reference
- effect permit

#### 출력

- result artifact
- execution status
- telemetry
- effect receipt
- evidence references
- errors / warnings
- rollback token 또는 recovery instruction

#### 불변조건

- plan 범위를 넘어서는 action을 수행하지 않는다.
- tool output을 artifact와 evidence로 구분한다.
- partial execution을 숨기지 않는다.
- retry는 idempotency와 effect semantics를 따른다.

### Critique Contract

#### 입력

- intent
- plan
- artifacts
- evidence
- execution telemetry
- policy
- evaluator profile

#### 출력

- criterion result
- detected issue
- severity
- confidence
- independent challenge
- pass / revise / human-review / reject
- remediation suggestion

#### 불변조건

- evaluator provenance를 기록한다.
- 실행자와 독립 reviewer를 연결할 수 있다.
- missing evidence는 pass로 처리하지 않는다.
- hard gate는 aggregate score로 상쇄되지 않는다.

### Compound Contract

#### 입력

- 완료 workflow history
- task recurrence
- critique outcome
- human override
- usage/effectiveness telemetry
- existing asset registry

#### 출력

- candidate type
- extracted pattern
- generalized input/output
- required Capability
- evidence
- risk
- proposed owner/reviewer
- suggested asset location
- promotion status

#### candidate type

```text
template
checklist
prompt
policy
workflow profile
capability
capability pack
kit update
failure rule
replay fixture
```

## 4. Lifecycle state machine

```mermaid
stateDiagram-v2
    [*] --> Draft
    Draft --> Planned
    Planned --> Unresolved
    Unresolved --> Planned
    Planned --> AwaitingApproval
    AwaitingApproval --> Approved
    AwaitingApproval --> Rejected
    Approved --> Running
    Running --> Waiting
    Waiting --> Running
    Running --> Failed
    Failed --> Planned
    Running --> Executed
    Executed --> Critiquing
    Critiquing --> Planned: revise
    Critiquing --> HumanReview
    HumanReview --> Planned: override/revise
    HumanReview --> Accepted
    Critiquing --> Accepted
    Accepted --> Compounding
    Compounding --> Completed
    Completed --> [*]
```

모든 workflow가 모든 상태를 거칠 필요는 없다. 그러나 mutation, 외부 communication, financial action, signing 등은 policy에 의해 mandatory approval state를 요구할 수 있다.

## 5. Effect Model

### Effect class

| Level | 예시 | 기본 정책 |
|---|---|---|
| `none` | 계산, 분류 | 자동 허용 가능 |
| `read-local` | local file 읽기 | scope 확인 |
| `read-external` | API 조회, web fetch | data policy 확인 |
| `write-local` | file 생성·수정 | preview/diff |
| `write-external` | SaaS record 변경 | explicit approval |
| `communicate` | 이메일·메시지 전송 | recipient/content approval |
| `financial` | 주문·결제·송금 | dual control |
| `legal-sign` | 계약 서명 | human-only |
| `destructive` | 삭제·취소 | explicit approval + rollback |
| `identity/admin` | 권한·계정 변경 | privileged gate |

Capability는 자신의 최대 effect를 manifest에 선언하고 각 invocation은 실제 effect를 더 좁게 선언한다.

## 6. Resolution Model

```text
Task Requirement
→ Capability ID / Interface
→ Compatible Capability Version
→ Available Adapter
→ Environment & Policy Check
→ Binding
```

예:

```text
Requirement: spreadsheet.range.write@^1
Candidates:
  - local-ooxml adapter
  - libreoffice adapter
  - remote-sheet adapter
Resolution inputs:
  file type, local availability, data policy, effect policy, fidelity need
```

특정 구현 이름은 초기 예시일 뿐이며 Core는 알지 않는다.

## 7. Kit Runtime

Kit는 다음을 제공한다.

- domain object schema
- workflow profile
- task templates
- policy bundle
- critique rubric
- human role/authority suggestions
- artifact templates
- recommended Capability
- sample fixture
- onboarding interview
- dashboard definition
- migration/version hooks

Kit가 직접 adapter를 구현할 수는 있지만, 재사용 가능성이 있으면 Capability Pack으로 분리해야 한다.

## 8. Event & Evidence Ledger

모든 중요한 transition은 append-only event로 기록한다.

```yaml
event:
  id:
  workflow_id:
  stage:
  actor:
  action:
  contract_version:
  input_hashes:
  output_hashes:
  effect:
  approval_ref:
  evidence_refs:
  status:
  timestamp:
  parent_event_hash:
```

### 핵심 원칙

- raw sensitive data를 event에 복제하지 않는다.
- artifact와 evidence는 content-addressed reference를 사용할 수 있다.
- plan, policy, capability version을 함께 기록한다.
- 사후 수정은 새 event와 새 revision으로 표현한다.
- export 가능한 human-readable decision narrative를 제공한다.

## 9. Experience Layer

### CLI

개발자와 자동화에 최적화. JSON output을 first-class로 유지한다.

### Desktop / Local UI

비개발자에게 plan preview, approval, artifact diff, critique, history를 시각화한다.

### API / MCP

외부 agent와 tool이 lifecycle contract를 사용하도록 한다.

### Progressive Disclosure

기본 사용자 경험:

```text
Install Kit
→ Describe Work
→ Review Plan
→ Approve Effects
→ Review Result
→ Save Improvement
```

전문가 경험:

```text
Inspect Contracts
→ Override Binding
→ Edit Policy
→ Add Capability
→ Review Compound Candidate
```

## 10. 제안 repository layout

```text
packages/
  contracts/
  core-runtime/
  planner/
  executor/
  critique/
  compound/
  policy/
  authority/
  evidence/
  capability-sdk/
  kit-sdk/
  registry/
  cli/
  desktop/

capabilities/
  spreadsheet/
  document/
  hwp/
  pdf/
  web/
  repository/
  database/
  communication/

kits/
  oss-maintainer/
  vc-screening/
  restaurant-ops/

examples/
fixtures/
docs/
```

## 11. Architecture fitness rules

CI에서 다음을 검사한다.

- Core package가 Kit package를 import하지 않는다.
- Core enum에 domain noun을 추가하지 않는다.
- Capability는 effect와 schema 없이 publish할 수 없다.
- Kit는 unavailable Capability에 대한 fallback 또는 requirement를 선언한다.
- side-effecting step은 policy gate를 우회할 수 없다.
- Critique 결과 없이 workflow를 Compound로 보내지 않는다.
- Compound candidate는 source run과 evidence를 참조한다.
