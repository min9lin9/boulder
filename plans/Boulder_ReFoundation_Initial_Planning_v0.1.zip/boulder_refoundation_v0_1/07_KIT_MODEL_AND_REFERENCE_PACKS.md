# Boulder Kit Model & Reference Capability Packs

## 1. Kit 정의

> **Kit는 특정 산업 또는 기능의 반복 업무를 실행하기 위해 workflow, policy, ontology, template, critique rubric과 Capability requirement를 조합한 설치 단위다.**

Kit는 Boulder fork가 아니다. Core를 import하되 Core가 Kit를 알지 못해야 한다.

## 2. Kit에 포함되는 것

```text
kit manifest
domain object schemas
workflow profiles
task templates
policy bundle
authority role suggestions
artifact templates
critique rubrics
recommended capabilities
onboarding interview
sample data / replay fixtures
dashboard definitions
migration scripts
documentation
```

`schemas/kit-manifest.example.yaml`에 초기 shape를 제안한다.

## 3. Capability Pack과 Kit의 차이

| 구분 | Capability Pack | Kit |
|---|---|---|
| 질문 | “무엇을 할 수 있는가?” | “이 업무를 어떻게 운영하는가?” |
| 범위 | tool/action | domain workflow |
| 예 | Spreadsheet Pack | VC Screening Kit |
| 재사용 | 여러 산업 | 특정 산업·기능 |
| policy | effect 중심 | business/authority 중심 |
| ontology | 거의 없음 | domain object 포함 |
| artifact | generic | domain template |

## 4. Universal Office Capability Pack

사용자가 명시한 Excel·한글 문서 기능은 Boulder Core가 아니라 **공용 Capability Pack**으로 설계한다.

```text
Office Pack
├─ Spreadsheet Pack
├─ Document Pack
├─ HWP/HWPX Pack
├─ PDF Pack
└─ Presentation Pack
```

각 Pack은 독립 release 가능하고 여러 adapter를 가질 수 있다.

## 5. Spreadsheet Pack 초안

### Capability family

```text
spreadsheet.workbook.inspect
spreadsheet.sheet.list
spreadsheet.range.read
spreadsheet.range.write
spreadsheet.formula.set
spreadsheet.formula.audit
spreadsheet.format.apply
spreadsheet.table.create
spreadsheet.chart.create
spreadsheet.named-range.manage
spreadsheet.data.validate
spreadsheet.workbook.diff
spreadsheet.workbook.recalculate
spreadsheet.workbook.export
spreadsheet.workbook.verify
```

### Plan 단계에서 보여줄 것

- 대상 workbook과 sheet
- 읽거나 바꿀 range
- formula와 value 변경
- format 변경
- 외부 link 영향
- recalculation 필요 여부
- 생성될 chart/table
- overwrite 위험
- backup/rollback 가능 여부

### Critique 단계

- formula error
- broken reference
- unexpected hardcode
- unit mismatch
- total/subtotal tie-out
- hidden sheet 영향
- workbook diff
- formatting consistency
- output schema와 template 준수

### Adapter 후보를 고르는 기준

초기 기획에서는 library를 확정하지 않는다. 다음 기준으로 prototype에서 선택한다.

- `.xlsx` fidelity
- formula 보존·계산
- chart/style 지원
- macro 처리와 보안
- cross-platform
- local-only 가능성
- license
- performance
- deterministic diff
- headless execution
- rollback

## 6. HWP/HWPX Pack 초안

HWP와 HWPX는 구현 난이도와 fidelity가 다를 수 있으므로 하나의 “한글 편집 기능”으로 뭉개지 않고 format driver를 분리한다.

### Capability family

```text
hwp.document.inspect
hwp.document.extract-text
hwp.document.extract-structure
hwp.document.replace-text
hwp.document.style.apply
hwp.document.table.read
hwp.document.table.write
hwp.document.image.insert
hwp.document.header-footer.edit
hwp.document.convert
hwp.document.diff
hwp.document.validate
```

### 단계적 가설

1. **Inspect / Extract MVP**  
   문서 구조와 text/table을 안전하게 읽는다.
2. **Template Fill MVP**  
   지정 placeholder와 table cell을 채운다.
3. **Controlled Edit MVP**  
   스타일과 layout 보존 범위가 명시된 편집.
4. **Conversion / Round-trip Test**  
   변환 후 손실을 Critique로 측정.
5. **Full-fidelity Driver 검토**  
   format, platform, license 조건이 확인된 뒤 결정.

### 반드시 검증할 risk

- format specification과 library license
- binary format round-trip fidelity
- font·layout 차이
- embedded object
- digital signature
- macro 또는 active content
- platform dependency
- 개인정보와 local processing 요구

“편집 가능”을 단일 boolean로 표시하지 않고 feature matrix와 fidelity grade를 제공한다.

## 7. Document / PDF / Presentation Pack

### Document

- paragraph/table/style
- template fill
- tracked diff
- metadata
- export
- structure validation

### PDF

- text/table extraction
- render
- merge/split
- annotation
- form fill
- provenance
- visual diff

### Presentation

- slide create/edit
- theme/layout
- chart/table
- speaker notes
- export
- visual QA

## 8. Reference Kit 1 — OSS Maintainer Kit

현재 Boulder의 핵심 vertical 기능을 추출한다.

### 포함

- repo inspection
- issue triage
- PR review prep
- release planning
- dependency review
- verification commands
- replay fixture
- Codex/GJC/LazyCodex presets
- product/service/release readiness
- contribution and security templates

### 사용하는 Capability

- repository
- shell/CI
- web/official docs
- document
- communication draft
- code analysis

이 Kit는 v1 compatibility를 보장하는 migration anchor다.

## 9. Reference Kit 2 — VC Screening Kit

### 대표 workflow

```text
Opportunity intake
→ evidence ingestion
→ company/entity resolution
→ mandate fit
→ financial normalization
→ preliminary valuation
→ risk scan
→ screening memo
→ independent challenge
→ human screening decision
```

### 필요한 Capability

- Document/PDF
- Spreadsheet
- Web Research
- Data Extraction
- Entity Resolution
- Financial Modeling
- Memo Generation
- Evidence/Citation
- Critique/Red Team

### Kit가 소유할 것

- Deal, Company, Fund 등 domain schema
- mandate policy
- screening memo template
- IC authority suggestion
- risk rubric
- evidence cutoff
- domain-specific hard failures

Core에는 이 noun을 추가하지 않는다.

## 10. Reference Kit 3 — Restaurant Ops Kit

### 대표 workflow

```text
Sales/import
→ inventory reconciliation
→ reorder proposal
→ supplier comparison
→ manager approval
→ purchase draft/order
→ receiving check
→ daily close report
→ recurring exception compound
```

### 필요한 Capability

- Spreadsheet
- POS/data connector
- Document
- Communication
- Scheduling
- Supplier web/API
- Notification
- Dashboard

### Kit가 소유할 것

- Menu Item, Ingredient, Supplier, Location, Shift
- reorder rule
- wastage policy
- manager authority
- daily close template
- food safety checklist
- exception threshold

## 11. 두-domain abstraction test

| 질문 | VC | Restaurant | Core 또는 공통 Pack |
|---|---|---|---|
| 입력 자료 수집 | CIM, financials | sales, inventory | Document/Spreadsheet |
| 계획 | screening plan | replenishment plan | Plan contract |
| 실행 | analysis, memo | reconcile, draft order | Capability runtime |
| critique | mandate/risk challenge | stock/price anomaly | Critique contract |
| human gate | screening decision | purchase approval | Authority |
| learning | recurring risk flag | recurring shortage | Compound |
| domain object | Deal, Fund | Ingredient, Shift | Kit-owned |
| common artifact | workbook, memo | workbook, report | Office Pack |

Core 수정 없이 두 workflow를 표현할 수 있어야 한다. 공통 기능이 반복되면 Capability Pack으로 올리고, domain rule이 섞이면 Kit에 남긴다.

## 12. Kit 설치 경험

```text
boulder kit inspect <kit>
boulder kit install <kit>
boulder kit doctor <kit>
boulder kit interview <kit>
boulder kit activate <kit>
boulder run <workflow>
```

초기 command 이름은 prototype이며 확정이 아니다.

설치 시 사용자에게 보여줄 것:

- Kit가 필요한 Capability
- data와 permission
- side-effect 범위
- human role
- unresolved dependency
- sample workflow
- trust/license
- local/remote execution
- compatibility
