# Boulder Design Thinking Foundation

## 1. 디자인 씽킹은 무엇에 적용되는가

`Plan → Execute → Critique → Compound`는 Boulder가 **업무를 운영하는 lifecycle**이다.

디자인 씽킹은 Boulder 자체를 **어떻게 발견하고 설계하고 검증할지**에 적용하는 제품 개발 방식이다. 둘을 혼동하지 않는다.

```text
Boulder를 설계하는 과정
Empathize → Define → Ideate → Prototype → Test

Boulder가 사용자의 업무를 운영하는 과정
Plan → Execute → Critique → Compound
```

Stanford d.school은 디자인 씽킹을 Empathize, Define, Ideate, Prototype, Test의 다섯 mode로 소개하며, 이를 선형 단계가 아니라 필요에 따라 오가는 도구 모음으로 설명한다. IDEO는 사람의 desirability, 기술적 feasibility, 조직·사업의 viability를 함께 보라고 강조한다. 이 기획은 두 관점을 결합한다.

## 2. Design Challenge

### 초기 문제문

> 다양한 산업의 사용자는 반복 업무를 자동화하고 싶지만, 현재 도구는 너무 범용적이어서 업무 맥락을 모르거나 너무 vertical해서 재사용이 어렵다. 실행 과정과 근거가 불투명하고, 외부 도구를 안전하게 연결하기 어렵고, 반복 작업에서 학습한 내용을 다음 작업에 구조적으로 재사용하기도 어렵다.

### How Might We

1. 어떻게 비개발자가 Kit를 설치한 뒤 15분 안에 안전한 첫 결과를 얻도록 할까?
2. 어떻게 Core를 바꾸지 않고 Excel, HWP, 웹, 데이터베이스 Capability를 추가하도록 할까?
3. 어떻게 VC와 요식업처럼 다른 산업을 하나의 lifecycle로 표현하되 도메인 의미를 잃지 않을까?
4. 어떻게 모든 side effect를 실행 전에 이해하고 승인할 수 있게 할까?
5. 어떻게 Critique가 Execute의 자기합리화가 되지 않도록 독립성을 유지할까?
6. 어떻게 Compound가 쓰레기 같은 자동 생성물의 축적이 아니라 검증된 조직 학습이 되게 할까?
7. 어떻게 Capability와 Kit의 신뢰도, 출처, license, 권한 요구를 설치 전에 알게 할까?
8. 어떻게 현재 Boulder 사용자의 자산을 버리지 않고 새 플랫폼으로 이동시킬까?

## 3. 핵심 가설

| ID | 가설 | 틀렸다는 신호 |
|---|---|---|
| H1 | 대부분의 디지털 업무는 Plan–Execute–Critique–Compound로 설명 가능하다 | 특정 업무가 lifecycle을 우회해야만 자연스럽다 |
| H2 | Capability와 Kit를 분리하면 산업 간 재사용성이 높아진다 | Kit마다 Capability를 fork한다 |
| H3 | 사용자는 완전 자율성보다 preview와 설명 가능한 통제를 선호한다 | approval이 반복 사용을 심각하게 방해한다 |
| H4 | Spreadsheet·Document 계열이 가장 높은 공통 재사용 가치를 가진다 | reference Kit가 office capability를 거의 공유하지 않는다 |
| H5 | 반복 작업의 evidence를 모으면 compound candidate를 안정적으로 발견할 수 있다 | candidate가 과도하게 많거나 품질이 낮다 |
| H6 | 현재 Boulder의 profile·handoff·gate·routine 구조는 재사용 가능하다 | 일반화 비용이 새로 만드는 비용보다 크다 |
| H7 | 두 개의 극단적으로 다른 reference Kit가 abstraction 품질을 빠르게 드러낸다 | 비교가 오히려 범위를 과도하게 넓힌다 |
| H8 | Local-first는 초기 신뢰와 도입 장벽을 낮춘다 | 필요한 collaboration·central control이 막힌다 |

## 4. Empathize — 누구에게 무엇을 배울 것인가

### 연구 대상

| 사용자군 | 최소 인터뷰 | 관찰할 업무 |
|---|---:|---|
| 비개발자 Operator | 5 | 반복 보고, 문서·spreadsheet 편집, 승인 |
| Domain Expert / Kit Author | 5 | 업무 규칙 설명, 예외 처리, 책임 경계 |
| Capability Developer | 5 | API 연결, schema, test, 배포·호환성 |
| Reviewer / Administrator | 4 | 권한, audit, compliance, rollback |
| 기존 Boulder 사용자·maintainer | 4 | 현재 가치, 병목, migration 위험 |

### 인터뷰 질문

#### Operator

- 최근 일주일에 세 번 이상 반복한 업무는 무엇인가?
- 그 업무를 시작할 때 가장 먼저 찾는 정보는 무엇인가?
- 자동화 결과를 믿지 못하게 만드는 순간은 언제인가?
- 실행 전에 반드시 확인해야 하는 것은 무엇인가?
- 실패했을 때 어떤 상태로 되돌아가야 안심되는가?
- “이 업무는 다음부터 자동으로 해도 된다”고 판단하는 조건은 무엇인가?

#### Domain Expert

- 업무 결과보다 더 중요한 판단 과정은 무엇인가?
- 절대 자동화하면 안 되는 결정은 무엇인가?
- 신입에게 업무를 넘길 때 어떤 checklist와 example을 주는가?
- 예외는 어디에서 가장 자주 발생하는가?
- 좋은 결과와 나쁜 결과를 가르는 숨은 기준은 무엇인가?

#### Capability Developer

- 새로운 integration을 만들 때 반복되는 boilerplate는 무엇인가?
- input/output, permission, side effect, rollback을 어떻게 표현하고 싶은가?
- local library와 remote API를 같은 contract로 다룰 수 있는가?
- compatibility break를 어떻게 감지하고 싶은가?
- 설치 전에 사용자에게 어떤 trust 정보를 보여줘야 하는가?

## 5. Define — 사용자 Job과 문제 프레임

### 핵심 Jobs-to-be-Done

#### Operator JTBD

> 반복 업무가 생겼을 때, 내가 사용하는 도구와 조직 규칙을 유지하면서도 실행 전에 내용을 검토하고, 결과와 근거를 남기며, 다음번에는 더 적은 노력으로 수행하고 싶다.

#### Kit Author JTBD

> 도메인 지식을 코드 전체에 박아 넣지 않고 workflow, policy, template, ontology로 포장해 다른 조직이 설치하고 수정하게 하고 싶다.

#### Capability Developer JTBD

> 하나의 기능을 여러 산업 Kit가 사용할 수 있도록 안정적인 contract, test harness, versioning, permission model과 함께 배포하고 싶다.

#### Administrator JTBD

> 어떤 Capability가 어떤 데이터와 시스템에 접근하며 어떤 side effect를 만들 수 있는지 파악하고, 필요한 human gate와 audit를 강제하고 싶다.

## 6. Ideate — 탐색할 구조 대안

### 대안 A: Mega Core

모든 office·web·industry 기능을 Boulder core에 포함.

- 장점: 초기 설치가 단순함
- 단점: core가 빠르게 비대해지고 domain coupling이 증가
- 판단: 기각 후보

### 대안 B: Thin Core + Capability + Kit

Core는 lifecycle·contract·policy만 제공하고 기능과 도메인을 외부 package로 분리.

- 장점: 확장성과 독립 배포
- 단점: SDK와 versioning 설계 비용
- 판단: 현재 우선안

### 대안 C: Kit가 자체 runtime 보유

각 Kit가 독립적으로 workflow engine을 포함하고 Boulder는 launcher만 담당.

- 장점: domain 자유도
- 단점: lifecycle, safety, audit가 파편화
- 판단: 제한적으로만 허용

### 대안 D: Hosted Marketplace 중심

Cloud registry와 hosted execution을 먼저 구축.

- 장점: 배포와 사용성이 좋을 수 있음
- 단점: 신뢰, 비용, 보안, scope가 초기 학습을 압도
- 판단: 초기 non-goal

## 7. Prototype — 학습 순서

### Prototype 0: 문서 prototype

현재 패키지의 Constitution, architecture, manifest example로 이해도를 검증한다.

### Prototype 1: No-build workflow storyboard

실제 code 없이 VC와 Restaurant workflow를 카드로 연결한다.

```text
Intent card
→ Plan card
→ Capability card
→ Effect/Approval card
→ Artifact card
→ Critique card
→ Compound candidate card
```

관찰 포인트:

- 사용자가 lifecycle을 이해하는가
- Capability와 Kit 차이를 설명할 수 있는가
- 승인 지점이 과도하거나 부족한가
- artifact와 evidence의 차이가 이해되는가

### Prototype 2: Wizard-of-Oz

백엔드는 사람이 운영하되 CLI/UI가 plan preview, approval, result, critique, learning을 보여준다. 실제 자동화보다 interaction과 trust를 먼저 검증한다.

### Prototype 3: Local vertical slice

Spreadsheet Pack의 `read → analyze → write → diff → verify`와 두 Kit의 한 workflow를 실제 실행한다.

### Prototype 4: External Capability

제3자가 문서만 보고 Capability 하나를 구현하도록 한다. 내부 팀의 설명이 필요하면 SDK가 충분히 명확하지 않은 것이다.

## 8. Test — 무엇을 측정하는가

### Desirability

- 사용자가 기존 방식 대신 Boulder를 다시 선택하는가
- Plan preview가 신뢰를 높이는가
- Kit 설치 개념이 이해되는가
- Compound candidate가 실제 재사용 욕구와 맞는가

### Feasibility

- 동일 Core에서 두 Kit를 실행할 수 있는가
- Capability contract가 local/remote adapter를 모두 표현하는가
- side-effect와 rollback을 기계적으로 검사할 수 있는가
- version mismatch가 실행 전에 감지되는가

### Viability / Sustainability

- Maintainer가 Core를 작게 유지할 수 있는가
- Kit와 Capability가 독립적으로 release 가능한가
- license와 trust review가 운영 가능한가
- community contribution이 review burden보다 큰 가치를 만드는가

## 9. 학습 기록 형식

모든 design experiment는 다음 형식으로 기록한다.

```yaml
experiment:
  id:
  hypothesis:
  participant_segment:
  prototype:
  task:
  observed_behavior:
  evidence:
  surprise:
  decision:
  next_experiment:
```

“좋아 보였다”는 결론으로 인정하지 않는다. 실제 행동, artifact, 완료 시간, 오류, 질문, 재사용 의사를 evidence로 남긴다.

## 10. 디자인 씽킹 적용의 종료 조건

디자인 씽킹은 끝없는 workshop이 아니다. 다음이 확보되면 implementation specification으로 넘어간다.

- 네 사용자군의 반복되는 핵심 Job이 확인됨
- 두-domain prototype에서 공통 Core 경계가 유지됨
- Capability manifest를 외부 개발자가 이해함
- preview/approval model이 사용성과 안전의 균형을 이룸
- 주요 risk와 non-goal이 합의됨
- v2 migration의 최소 호환 경로가 정의됨
