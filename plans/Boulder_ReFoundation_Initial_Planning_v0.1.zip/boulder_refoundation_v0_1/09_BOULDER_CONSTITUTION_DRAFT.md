# Boulder Constitution — Draft 0.1

이 문서는 구현 상세가 아니라 Boulder가 장기적으로 지켜야 할 제품·아키텍처 원칙을 정의한다. 변경하려면 명시적 ADR, 사용자 영향, migration 계획과 검증 evidence가 필요하다.

## Article 1 — Boulder Serves Human Intent

Boulder의 목적은 인간의 의도를 대체하는 것이 아니라 명확하게 만들고 안전하게 실행하며 학습 가능하게 하는 것이다.

## Article 2 — The Public Lifecycle Is Stable

Boulder의 핵심 lifecycle은 다음이다.

```text
Plan → Execute → Critique → Compound
```

내부 lane은 발전할 수 있으나 public mental model을 불필요하게 깨지 않는다.

## Article 3 — Core Is Domain-Neutral

Core에는 VC의 Deal, Restaurant의 Ingredient, OSS의 Pull Request 같은 domain noun을 추가하지 않는다. Domain semantics는 Kit가 소유한다.

## Article 4 — Capabilities Are Replaceable

특정 model, agent, library, file engine, SaaS는 default adapter일 수 있지만 Core dependency가 아니다.

## Article 5 — Effects Must Be Declared

외부 세계나 상태를 바꾸는 모든 행위는 effect, scope, permission과 approval requirement를 선언한다.

## Article 6 — No Silent Mutation

사용자가 이해할 수 없는 방식으로 file, database, message, financial, identity 상태를 변경하지 않는다. 위험한 변경에는 preview와 명시적 gate가 필요하다.

## Article 7 — Evidence Precedes Claims

완료, 품질, readiness, 안전, 성능에 관한 주장은 검토 가능한 evidence와 연결돼야 한다.

## Article 8 — Critique Is Independently Routable

실행과 검토를 분리할 수 있어야 하며, hard failure는 평균 점수로 상쇄되지 않는다.

## Article 9 — Human Authority Is a First-Class Contract

Approve, reject, veto, override, delegate, sign과 같은 권한은 prompt가 아니라 구조화된 event와 policy로 표현한다.

## Article 10 — Compound Requires Review

반복 pattern을 자동으로 영구 자산으로 publish하지 않는다. evidence, generality, owner, test와 인간 검토를 거친다.

## Article 11 — Kits Compose; They Do Not Fork the Platform

Kit는 Core contract를 조합한다. Kit별 Core fork를 정상 확장 방식으로 인정하지 않는다.

## Article 12 — Capabilities Are Smaller Than Roles

Capability는 Analyst, Manager 같은 persona가 아니라 검증 가능한 행위와 interface로 정의한다.

## Article 13 — Local-First, Network-Explicit

가능한 workflow는 local-first로 실행하고 외부 전송·실행은 manifest와 plan에서 명시한다.

## Article 14 — Security Is a Contract Property

path safety, data classification, permission, provenance, trust, sandbox, rollback은 부가 기능이 아니라 Capability와 workflow의 필수 속성이다.

## Article 15 — Contracts Are Versioned

Public schema와 behavior는 version을 갖고 breaking change에는 migration과 deprecation 기간이 필요하다.

## Article 16 — Progressive Disclosure

초보 사용자는 Kit와 preview를 이해하면 되고, 전문가만 adapter와 policy 내부를 다룬다.

## Article 17 — Failure Must Be Legible

Blocked, partial, failed, waiting, manual handoff를 정상 상태로 표현한다. 실패를 success 문구 뒤에 숨기지 않는다.

## Article 18 — Open Source Includes Governance

source code뿐 아니라 contribution, review, trust, license, security disclosure, deprecation 절차를 공개한다.

## Article 19 — The Core Must Stay Smaller Than the Ecosystem

성공한 Boulder에서 대부분의 domain value는 Capability와 Kit에 존재해야 한다. Core 기능 수가 ecosystem보다 빠르게 늘면 경계를 재검토한다.

## Article 20 — Current Users Are Not Collateral Damage

재기획은 기존 사용자의 workflow와 evidence를 무시하지 않는다. v1 기능은 compatibility layer와 OSS Maintainer Kit를 통해 단계적으로 이동한다.

## Amendment Process

Constitution 변경 제안에는 다음이 필요하다.

```text
Problem
User evidence
Article affected
Proposed change
Rejected alternatives
Core/Capability/Kit impact
Security and migration impact
Prototype or fixture
Decision owner
Review period
```

긴급 security amendment를 제외하면 최소 한 번의 공개 review cycle을 거친다.
